﻿using phone;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace phone
{
    public class Order
    {
        public int OrderId { get; set; }
        public int CustomerId { get; set; }
        public string CustomerFullName { get; set; } // Для удобства отображения
        public DateTime OrderDate { get; set; }
        public decimal TotalAmount { get; set; }
        public string Status { get; set; } // Например, "Новый", "В обработке", "Доставлен"

        public List<OrderDetail> Details { get; set; } = new List<OrderDetail>();
    }
}
