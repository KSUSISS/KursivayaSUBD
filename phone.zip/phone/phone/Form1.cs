﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace phone
{
    public partial class Form1 : Form
    {
        // Строка подключения к базе данных PostgreSQL
                private string connString = "Host=localhost;Port=5432;Database=PhonesDB;Username=postgres;Password=Mr228DKOM";

        private NpgsqlConnection conn;
        private DataTable currentDataTable; // Для хранения текущих данных, отображаемых в DataGridView
        private string currentTableName; // Для отслеживания текущей таблицы




        public Form1()
        {
            
            InitializeComponent();
            InitializeDatabaseConnection();
        }
        private void InitializeDatabaseConnection()
        {
            try
            {
                conn = new NpgsqlConnection(connString);
                conn.Open();
                MessageBox.Show("Подключение к базе данных успешно!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к базе данных: " + ex.Message);
            }
        }
        // Метод для загрузки данных в DataGridView
        private void LoadData(string tableName)
        {
            if (conn.State != ConnectionState.Open)
            {
                MessageBox.Show("Соединение с базой данных не установлено.");
                return;
            }

            try
            {
                string sql = $"SELECT * FROM {tableName}";
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(sql, conn);
                currentDataTable = new DataTable();
                dataAdapter.Fill(currentDataTable);
                dataGridView1.DataSource = currentDataTable;
                currentTableName = tableName;

                // Для автоматической генерации команд INSERT, UPDATE, DELETE
                
                NpgsqlCommandBuilder commandBuilder = new NpgsqlCommandBuilder(dataAdapter);
 
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных из таблицы {tableName}: {ex.Message}");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            if (conn != null && conn.State == ConnectionState.Open)
            {
                conn.Close();
                conn.Dispose();
            }
        }

        private void btnLoadCategories_Click(object sender, EventArgs e)
        {
            LoadData("categories");
        }

        private void btnLoadProducts_Click(object sender, EventArgs e)
        {
            LoadData("products");
        }

        private void btnLoadCustomers_Click(object sender, EventArgs e)
        {
            LoadData("customers");
        }

        private void btnLoadOrders_Click(object sender, EventArgs e)
        {
            LoadData("orders");
        }

        private void btnLoadOrdersDetails_Click(object sender, EventArgs e)
        {
            LoadData("order_details");
        }

        private void btnSaveAddRow_Click(object sender, EventArgs e)
        {
            if (currentDataTable == null || string.IsNullOrEmpty(currentTableName))
            {
                MessageBox.Show("Не выбрана таблица для добавления записи.");
                return;
            }

            // Создаем новую строку в DataTable
            DataRow newRow = currentDataTable.NewRow();

         
            if (currentTableName == "categories")
            {
                newRow["category_name"] = "Новая Категория " + Guid.NewGuid().ToString().Substring(0, 5);
                newRow["description"] = "Описание новой категории";
            }
           

            currentDataTable.Rows.Add(newRow); // Добавляем строку в DataTable
            MessageBox.Show("Новая строка добавлена локально. Нажмите 'Сохранить изменения' для записи в БД.");
        }

        private void btnSaveChages_Click(object sender, EventArgs e)
        {
            if (currentDataTable == null || string.IsNullOrEmpty(currentTableName))
            {
                MessageBox.Show("Не выбрана таблица для сохранения изменений.");
                return;
            }

            try
            {
                string sql = $"SELECT * FROM {currentTableName}"; // Перезагружаем DataAdapter для текущей таблицы
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(sql, conn);
                NpgsqlCommandBuilder commandBuilder = new NpgsqlCommandBuilder(dataAdapter);

                dataAdapter.Update(currentDataTable); // Отправляем изменения в базу данных
                MessageBox.Show("Изменения успешно сохранены!");
                LoadData(currentTableName); // Перезагружаем данные для отображения изменений
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении изменений: " + ex.Message);
            }
        }

        private void btnDeleteRow_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Получаем индекс выбранной строки
                int selectedIndex = dataGridView1.SelectedRows[0].Index;
                dataGridView1.Rows.RemoveAt(selectedIndex); // Удаляем строку из DataGridView
                MessageBox.Show("Строка удалена локально. Нажмите 'Сохранить изменения' для записи в БД.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления.");
            }
        }
    }
}
