﻿namespace phone
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadCategories = new System.Windows.Forms.Button();
            this.btnLoadProducts = new System.Windows.Forms.Button();
            this.btnLoadCustomers = new System.Windows.Forms.Button();
            this.btnLoadOrders = new System.Windows.Forms.Button();
            this.btnLoadOrdersDetails = new System.Windows.Forms.Button();
            this.btnSaveAddRow = new System.Windows.Forms.Button();
            this.btnSaveChages = new System.Windows.Forms.Button();
            this.btnDeleteRow = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLoadCategories
            // 
            this.btnLoadCategories.Location = new System.Drawing.Point(12, 12);
            this.btnLoadCategories.Name = "btnLoadCategories";
            this.btnLoadCategories.Size = new System.Drawing.Size(136, 59);
            this.btnLoadCategories.TabIndex = 0;
            this.btnLoadCategories.Text = "Загрузить Категории";
            this.btnLoadCategories.UseVisualStyleBackColor = true;
            this.btnLoadCategories.Click += new System.EventHandler(this.btnLoadCategories_Click);
            // 
            // btnLoadProducts
            // 
            this.btnLoadProducts.Location = new System.Drawing.Point(177, 12);
            this.btnLoadProducts.Name = "btnLoadProducts";
            this.btnLoadProducts.Size = new System.Drawing.Size(136, 59);
            this.btnLoadProducts.TabIndex = 1;
            this.btnLoadProducts.Text = "Загрузить Продукты";
            this.btnLoadProducts.UseVisualStyleBackColor = true;
            this.btnLoadProducts.Click += new System.EventHandler(this.btnLoadProducts_Click);
            // 
            // btnLoadCustomers
            // 
            this.btnLoadCustomers.Location = new System.Drawing.Point(342, 12);
            this.btnLoadCustomers.Name = "btnLoadCustomers";
            this.btnLoadCustomers.Size = new System.Drawing.Size(136, 59);
            this.btnLoadCustomers.TabIndex = 2;
            this.btnLoadCustomers.Text = "Загрузить Клиенты";
            this.btnLoadCustomers.UseVisualStyleBackColor = true;
            this.btnLoadCustomers.Click += new System.EventHandler(this.btnLoadCustomers_Click);
            // 
            // btnLoadOrders
            // 
            this.btnLoadOrders.Location = new System.Drawing.Point(498, 12);
            this.btnLoadOrders.Name = "btnLoadOrders";
            this.btnLoadOrders.Size = new System.Drawing.Size(136, 59);
            this.btnLoadOrders.TabIndex = 3;
            this.btnLoadOrders.Text = "Загрузить Заказы";
            this.btnLoadOrders.UseVisualStyleBackColor = true;
            this.btnLoadOrders.Click += new System.EventHandler(this.btnLoadOrders_Click);
            // 
            // btnLoadOrdersDetails
            // 
            this.btnLoadOrdersDetails.Location = new System.Drawing.Point(652, 12);
            this.btnLoadOrdersDetails.Name = "btnLoadOrdersDetails";
            this.btnLoadOrdersDetails.Size = new System.Drawing.Size(136, 59);
            this.btnLoadOrdersDetails.TabIndex = 4;
            this.btnLoadOrdersDetails.Text = "Загрузить детали заказов";
            this.btnLoadOrdersDetails.UseVisualStyleBackColor = true;
            this.btnLoadOrdersDetails.Click += new System.EventHandler(this.btnLoadOrdersDetails_Click);
            // 
            // btnSaveAddRow
            // 
            this.btnSaveAddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnSaveAddRow.ForeColor = System.Drawing.Color.White;
            this.btnSaveAddRow.Location = new System.Drawing.Point(12, 87);
            this.btnSaveAddRow.Name = "btnSaveAddRow";
            this.btnSaveAddRow.Size = new System.Drawing.Size(136, 32);
            this.btnSaveAddRow.TabIndex = 5;
            this.btnSaveAddRow.Text = "Добавить ";
            this.btnSaveAddRow.UseVisualStyleBackColor = false;
            this.btnSaveAddRow.Click += new System.EventHandler(this.btnSaveAddRow_Click);
            // 
            // btnSaveChages
            // 
            this.btnSaveChages.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnSaveChages.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveChages.ForeColor = System.Drawing.Color.White;
            this.btnSaveChages.Location = new System.Drawing.Point(154, 87);
            this.btnSaveChages.Name = "btnSaveChages";
            this.btnSaveChages.Size = new System.Drawing.Size(136, 32);
            this.btnSaveChages.TabIndex = 6;
            this.btnSaveChages.Text = "Сохранить";
            this.btnSaveChages.UseVisualStyleBackColor = false;
            this.btnSaveChages.Click += new System.EventHandler(this.btnSaveChages_Click);
            // 
            // btnDeleteRow
            // 
            this.btnDeleteRow.BackColor = System.Drawing.Color.Red;
            this.btnDeleteRow.ForeColor = System.Drawing.Color.White;
            this.btnDeleteRow.Location = new System.Drawing.Point(296, 87);
            this.btnDeleteRow.Name = "btnDeleteRow";
            this.btnDeleteRow.Size = new System.Drawing.Size(136, 32);
            this.btnDeleteRow.TabIndex = 7;
            this.btnDeleteRow.Text = "Удалить";
            this.btnDeleteRow.UseVisualStyleBackColor = false;
            this.btnDeleteRow.Click += new System.EventHandler(this.btnDeleteRow_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(12, 125);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(136, 32);
            this.button8.TabIndex = 8;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 180);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(776, 258);
            this.dataGridView1.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.btnDeleteRow);
            this.Controls.Add(this.btnSaveChages);
            this.Controls.Add(this.btnSaveAddRow);
            this.Controls.Add(this.btnLoadOrdersDetails);
            this.Controls.Add(this.btnLoadOrders);
            this.Controls.Add(this.btnLoadCustomers);
            this.Controls.Add(this.btnLoadProducts);
            this.Controls.Add(this.btnLoadCategories);
            this.Name = "Form1";
            this.Text = "Магазин Б/У Сотовых телефонов ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoadCategories;
        private System.Windows.Forms.Button btnLoadProducts;
        private System.Windows.Forms.Button btnLoadCustomers;
        private System.Windows.Forms.Button btnLoadOrders;
        private System.Windows.Forms.Button btnLoadOrdersDetails;
        private System.Windows.Forms.Button btnSaveAddRow;
        private System.Windows.Forms.Button btnSaveChages;
        private System.Windows.Forms.Button btnDeleteRow;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

