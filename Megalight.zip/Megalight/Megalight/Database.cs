﻿using Npgsql; // Подключаем библиотеку
using System;
using System.Data;
using System.Windows.Forms;
namespace Megalight
{
    public class Database
    {
        private static string connectionString =
            "Host=localhost;Port=5432;Database=PhonesDB;Username=postgres;Password=MR228DKOM";

        public static NpgsqlConnection GetConnection()
        { 
            return new NpgsqlConnection(connectionString);
        }
    }
}
