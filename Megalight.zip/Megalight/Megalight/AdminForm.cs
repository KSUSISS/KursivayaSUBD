﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Megalight
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();

        }



        private void LoadCategories()
        {
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter("SELECT * FROM categories ORDER BY name", conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    lstCategories.DataSource = dt;
                    lstCategories.DisplayMember = "name";
                    lstCategories.ValueMember = "category_id";
                }
            }
            catch { }
        }

        private void LoadSuppliers()
        {
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter("SELECT * FROM suppliers ORDER BY name", conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvSuppliers.DataSource = dt;
                    if (dgvSuppliers.Columns["supplier_id"] != null) dgvSuppliers.Columns["supplier_id"].Visible = false;
                }
            }
            catch { }
        }

        private void LoadEmployees()
        {
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    // Выбираем данные, кроме пароля (его лучше не показывать в таблице)
                    string sql = "SELECT employee_id, fio, role, login, password_hash FROM employees ORDER BY fio";

                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Убедись, что таблица на вкладке сотрудников называется dgvEmployees !
                    dgvEmployees.DataSource = dt;

                    // Скрываем ID
                    if (dgvEmployees.Columns["employee_id"] != null)
                        dgvEmployees.Columns["employee_id"].Visible = false;

                    // Русифицируем заголовки (если они не настроены в дизайнере)
                    if (dgvEmployees.Columns["fio"] != null) dgvEmployees.Columns["fio"].HeaderText = "ФИО";
                    if (dgvEmployees.Columns["role"] != null) dgvEmployees.Columns["role"].HeaderText = "Роль";
                    if (dgvEmployees.Columns["login"] != null) dgvEmployees.Columns["login"].HeaderText = "Логин";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки сотрудников: " + ex.Message);
            }
        }

        private void btnBackup_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "SQL Backup|*.sql";
            sfd.FileName = $"Backup_{DateTime.Now:yyyyMMdd}.sql";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                // Путь к pg_dump (УКАЖИ СВОЮ ВЕРСИЮ!)
                string pgDumpPath = @"C:\Program Files\PostgreSQL\16\bin\pg_dump.exe";
                string pass = "1234"; // Твой пароль

                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = pgDumpPath;
                    // Используем Plain формат (-F p), чтобы можно было читать глазами
                    psi.Arguments = $"--host=localhost --username=postgres --format=p --file=\"{sfd.FileName}\" mobile_shop";
                    psi.EnvironmentVariables["PGPASSWORD"] = pass;
                    psi.UseShellExecute = false;
                    psi.CreateNoWindow = true;

                    using (Process p = Process.Start(psi))
                    {
                        p.WaitForExit();
                        if (p.ExitCode == 0) MessageBox.Show("Бэкап создан!");
                        else MessageBox.Show("Ошибка создания бэкапа (Код " + p.ExitCode + ")");
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
        }

        private void btnOpenAddSupplier_Click(object sender, EventArgs e)
        {
            AddSupplierForm form = new AddSupplierForm();
            if (form.ShowDialog() == DialogResult.OK) LoadSuppliers();
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNewCategoryName.Text)) return;
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    using (var cmd = new NpgsqlCommand("INSERT INTO categories (name) VALUES (@n)", conn))
                    {
                        cmd.Parameters.AddWithValue("n", txtNewCategoryName.Text);
                        cmd.ExecuteNonQuery();
                    }
                }
                txtNewCategoryName.Clear();
                LoadCategories();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            if (lstCategories.SelectedValue == null) return;
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    using (var cmd = new NpgsqlCommand("DELETE FROM categories WHERE category_id = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("id", lstCategories.SelectedValue);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadCategories();
            }
            catch { MessageBox.Show("Нельзя удалить категорию с товарами!"); }

        }

        private void btnDeleteSupplier_Click(object sender, EventArgs e)
        {
            if (dgvSuppliers.SelectedRows.Count == 0) return;
            int id = Convert.ToInt32(dgvSuppliers.SelectedRows[0].Cells["supplier_id"].Value);
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    using (var cmd = new NpgsqlCommand("DELETE FROM suppliers WHERE supplier_id = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadSuppliers();
            }
            catch { MessageBox.Show("Ошибка удаления!"); }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnShowReport_Click(object sender, EventArgs e)
        {
            DateTime start = dtpStart.Value.Date;
            DateTime end = dtpEnd.Value.Date.AddDays(1).AddSeconds(-1);
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();

                    // --- 1. СТРОИМ ГРАФИК (Выручка по дням) ---
                    chartRevenue.Series["Выручка"].Points.Clear();

                    string sqlChart = @"
                        SELECT date(sale_date) as day, SUM(total_amount) as sum 
                        FROM sales 
                        WHERE sale_date BETWEEN @s AND @e 
                        GROUP BY day 
                        ORDER BY day";

                    using (var cmd = new NpgsqlCommand(sqlChart, conn))
                    {
                        cmd.Parameters.AddWithValue("s", start);
                        cmd.Parameters.AddWithValue("e", end);

                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                DateTime day = Convert.ToDateTime(reader["day"]);
                                decimal sum = Convert.ToDecimal(reader["sum"]);

                                // Добавляем столбик на график
                                chartRevenue.Series["Выручка"].Points.AddXY(day.ToString("dd.MM"), sum);
                            }
                        }
                    }

                    // --- 2. СЧИТАЕМ ИТОГИ (Выручка и Прибыль) ---
                    // Прибыль = (Продажи) - (Закупки поставок + Скупка телефонов + Зарплата мастера)
                    // Для курсовой можно упростить: Прибыль = Сумма продаж за период - Себестоимость проданного

                    // Для простоты посчитаем "Грязную прибыль" (Выручка) и примерную "Чистую"

                    // Общая выручка
                    string sqlTotalRev = "SELECT COALESCE(SUM(total_amount), 0) FROM sales WHERE sale_date BETWEEN @s AND @e";

                    decimal revenue = 0;
                    using (var cmd = new NpgsqlCommand(sqlTotalRev, conn))
                    {
                        cmd.Parameters.AddWithValue("s", start);
                        cmd.Parameters.AddWithValue("e", end);
                        revenue = (decimal)cmd.ExecuteScalar();
                    }

                    // Вывод в лейблы
                 


                    // Примерный расчет прибыли (допустим, маржа 30% или вычитаем закупки)
                    // Чтобы посчитать точно, нужно лезть в sale_items -> devices -> intake_price. 
                    // Сделаем SQL запрос на "Сумму прибыли по чекам"
                    string sqlProfit = @"
                        SELECT SUM(si.price_at_moment - COALESCE(d.total_cost, 0) - COALESCE(a.purchase_price, 0))
                        FROM sale_items si
                        LEFT JOIN devices d ON si.device_id = d.device_id
                        LEFT JOIN accessories a ON si.accessory_id = a.accessory_id
                        JOIN sales s ON si.sale_id = s.sale_id
                        WHERE s.sale_date BETWEEN @s AND @e";

                    decimal profit = 0;
                    using (var cmd = new NpgsqlCommand(sqlProfit, conn))
                    {
                        cmd.Parameters.AddWithValue("s", start);
                        cmd.Parameters.AddWithValue("e", end);
                        var result = cmd.ExecuteScalar();
                        if (result != DBNull.Value) profit = (decimal)result;
                    }
                    lblTotalProfit.Text = $"Чистая прибыль: {profit:C0}";

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка построения отчета: " + ex.Message);
            }
        }

        private void btnRestore_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Восстановление заменит текущую базу данных. Продолжить?", "Опасно", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No) return;

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "SQL Backup|*.sql";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string psqlPath = @"C:\Program Files\PostgreSQL\16\bin\psql.exe"; // Для восстановления .sql нужен psql
                string pass = "1234";

                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = psqlPath;
                    // psql -U postgres -d mobile_shop -f файл.sql
                    psi.Arguments = $"--host=localhost --username=postgres --dbname=mobile_shop --file=\"{ofd.FileName}\"";
                    psi.EnvironmentVariables["PGPASSWORD"] = pass;
                    psi.UseShellExecute = false;
                    psi.CreateNoWindow = true;

                    using (Process p = Process.Start(psi))
                    {
                        p.WaitForExit();
                        if (p.ExitCode == 0)
                        {
                            MessageBox.Show("База восстановлена!");
                            // После восстановления лучше перезагрузить данные на форме
                            LoadCategories();
                            LoadSuppliers();
                        }
                        else MessageBox.Show("Ошибка восстановления (Код " + p.ExitCode + ")");
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
        }

        private void tabControl1_Layout(object sender, LayoutEventArgs e)
        {

        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            LoadCategories();
            LoadSuppliers();
            SetupChart();
            LoadSupplyLists();
            LoadEmployees();
        }

        private void btnOpenManager_Click(object sender, EventArgs e)
        {
            ManagerForm form = new ManagerForm();
            form.Show();
        }

        private void btnOpenMaster_Click(object sender, EventArgs e)
        {
            MasterForm form = new MasterForm();
            form.Show();
        }

        private void SetupChart()
        {
            chartRevenue.Series.Clear();
            Series series = new Series("Выручка");
            series.ChartType = SeriesChartType.Column; // Столбчатая диаграмма
            series.Color = System.Drawing.Color.Green;
            chartRevenue.Series.Add(series);

            chartRevenue.ChartAreas[0].AxisX.Title = "Дата";
            chartRevenue.ChartAreas[0].AxisY.Title = "Сумма (руб)";
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUserFio.Text) ||
       string.IsNullOrWhiteSpace(txtUserLogin.Text) ||
       string.IsNullOrWhiteSpace(txtUserPass.Text))
            {
                MessageBox.Show("Заполните ФИО, Логин и Пароль!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbUserRole.SelectedItem == null)
            {
                MessageBox.Show("Выберите роль (admin, manager или master)!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();

                    // Хешируем пароль
                    string passHash = HashPassword(txtUserPass.Text.Trim());

                    string sql = @"
                INSERT INTO employees (fio, login, password_hash, role) 
                VALUES (@fio, @login, @pass, @role::employee_role)";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("fio", txtUserFio.Text.Trim());
                        cmd.Parameters.AddWithValue("login", txtUserLogin.Text.Trim());
                        cmd.Parameters.AddWithValue("pass", passHash);
                        cmd.Parameters.AddWithValue("role", cmbUserRole.SelectedItem.ToString());

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Сотрудник добавлен!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Очищаем поля
                txtUserFio.Clear();
                txtUserLogin.Clear();
                txtUserPass.Clear();
                cmbUserRole.SelectedIndex = -1;

                // Обновляем таблицу
                LoadEmployees();
            }
            catch (PostgresException ex)
            {
                if (ex.SqlState == "23505") // Ошибка уникальности
                {
                    MessageBox.Show("Сотрудник с таким логином уже существует!");
                }
                else
                {
                    MessageBox.Show("Ошибка БД: " + ex.Message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            if (dgvEmployees.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите сотрудника для увольнения!");
                return;
            }

            if (MessageBox.Show("Уволить сотрудника?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No) return;

            try
            {
                // Берем ID из выделенной строки
                // Убедись, что колонка называется employee_id (как в базе) или индекс 0
                int id = Convert.ToInt32(dgvEmployees.SelectedRows[0].Cells["employee_id"].Value);

                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    string sql = "DELETE FROM employees WHERE employee_id = @id";
                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadEmployees(); // Обновляем список
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message);
            }
        }

        private decimal currentSupplyTotal = 0;

        private class SupplyItemDraft
        {
            public int Id { get; set; }
            public string Type { get; set; } // "part" или "accessory"
            public string Name { get; set; }
            public int Qty { get; set; }
            public decimal Price { get; set; } // Цена закупки

            public override string ToString()
            {
                return $"{Name} (x{Qty}) — {Price:C0}/шт. = {Price * Qty:C0}";
            }
        }

        private void LoadSupplyLists()
        {
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();

                    // 1. ЗАГРУЗКА ПОСТАВЩИКОВ
                    string sqlSup = "SELECT supplier_id, name FROM suppliers ORDER BY name";
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sqlSup, conn);
                    DataTable dtSup = new DataTable();
                    da.Fill(dtSup);

                    // Привязываем к выпадающему списку
                    cmbSupplySupplier.DataSource = dtSup;
                    cmbSupplySupplier.DisplayMember = "name";       // Показываем Имя
                    cmbSupplySupplier.ValueMember = "supplier_id";  // Внутри храним ID

                    // 2. ЗАГРУЗКА ТОВАРОВ (по умолчанию Аксессуары)
                    LoadSupplyProducts("accessory");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки списков: " + ex.Message);
            }
        }

        private void LoadSupplyProducts(string type)
        {
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    string sql = "";

                    if (type == "accessory")
                        sql = "SELECT accessory_id as id, name FROM accessories ORDER BY name";
                    else
                        sql = "SELECT part_id as id, name FROM parts ORDER BY name";

                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    cmbSupplyProduct.DataSource = dt;
                    cmbSupplyProduct.DisplayMember = "name";
                    cmbSupplyProduct.ValueMember = "id";
                }
            }
            catch { }
        }

        private void rbAccessory_CheckedChanged(object sender, EventArgs e)
        {
            if (rbAccessory.Checked) LoadSupplyProducts("accessory");
        }

        private void rbPart_CheckedChanged(object sender, EventArgs e)
        {
            if (rbPart.Checked) LoadSupplyProducts("part");
        }

        private void btnAddSupplyItem_Click(object sender, EventArgs e)
        {
            if (cmbSupplyProduct.SelectedValue == null) return;

            SupplyItemDraft item = new SupplyItemDraft
            {
                Id = (int)cmbSupplyProduct.SelectedValue,
                Type = rbAccessory.Checked ? "accessory" : "part",
                Name = cmbSupplyProduct.Text,
                Qty = (int)numSupplyQty.Value,
                Price = numSupplyPrice.Value
            };

            lstSupplyDraft.Items.Add(item);

            currentSupplyTotal += item.Price * item.Qty;
            lblSupplyTotal.Text = $"Итого: {currentSupplyTotal:C0}";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (lstSupplyDraft.Items.Count == 0) return;
            if (cmbSupplySupplier.SelectedValue == null) return;

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    using (var transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            // 1. Создаем запись в supplies
                            string sqlHead = "INSERT INTO supplies (supplier_id, employee_id, total_amount) VALUES (@sup, @emp, @sum) RETURNING supply_id";

                            int supplyId;
                            using (var cmd = new NpgsqlCommand(sqlHead, conn))
                            {
                                cmd.Transaction = transaction;
                                cmd.Parameters.AddWithValue("sup", cmbSupplySupplier.SelectedValue);
                                cmd.Parameters.AddWithValue("emp", 1); // ID Админа (заглушка)
                                cmd.Parameters.AddWithValue("sum", currentSupplyTotal);
                                supplyId = (int)cmd.ExecuteScalar();
                            }

                            // 2. Проходим по списку товаров
                            foreach (SupplyItemDraft item in lstSupplyDraft.Items)
                            {
                                string sqlItem = "";
                                string sqlUpdateStock = "";

                                if (item.Type == "accessory")
                                {
                                    // Добавляем Аксессуар
                                    sqlItem = "INSERT INTO supply_items (supply_id, accessory_id, quantity, price) VALUES (@sid, @aid, @qty, @price)";

                                    // УВЕЛИЧИВАЕМ СКЛАД + ОБНОВЛЯЕМ ЦЕНУ ЗАКУПКИ
                                    sqlUpdateStock = "UPDATE accessories SET stock_quantity = stock_quantity + @qty, purchase_price = @price WHERE accessory_id = @aid";

                                    using (var cmdUpd = new NpgsqlCommand(sqlUpdateStock, conn))
                                    {
                                        cmdUpd.Transaction = transaction;
                                        cmdUpd.Parameters.AddWithValue("qty", item.Qty);
                                        cmdUpd.Parameters.AddWithValue("price", item.Price); // Обновляем себестоимость
                                        cmdUpd.Parameters.AddWithValue("aid", item.Id);
                                        cmdUpd.ExecuteNonQuery();
                                    }
                                }
                                else
                                {
                                    // Добавляем Запчасть
                                    sqlItem = "INSERT INTO supply_items (supply_id, part_id, quantity, price) VALUES (@sid, @pid, @qty, @price)";

                                    // УВЕЛИЧИВАЕМ СКЛАД ЗАПЧАСТЕЙ
                                    sqlUpdateStock = "UPDATE parts SET stock_quantity = stock_quantity + @qty, purchase_price = @price WHERE part_id = @pid";

                                    using (var cmdUpd = new NpgsqlCommand(sqlUpdateStock, conn))
                                    {
                                        cmdUpd.Transaction = transaction;
                                        cmdUpd.Parameters.AddWithValue("qty", item.Qty);
                                        cmdUpd.Parameters.AddWithValue("price", item.Price);
                                        cmdUpd.Parameters.AddWithValue("pid", item.Id);
                                        cmdUpd.ExecuteNonQuery();
                                    }
                                }

                                // Записываем в supply_items
                                using (var cmdItem = new NpgsqlCommand(sqlItem, conn))
                                {
                                    cmdItem.Transaction = transaction;
                                    cmdItem.Parameters.AddWithValue("sid", supplyId);

                                    if (item.Type == "accessory") cmdItem.Parameters.AddWithValue("aid", item.Id);
                                    else cmdItem.Parameters.AddWithValue("pid", item.Id);

                                    cmdItem.Parameters.AddWithValue("qty", item.Qty);
                                    cmdItem.Parameters.AddWithValue("price", item.Price);
                                    cmdItem.ExecuteNonQuery();
                                }
                            }

                            transaction.Commit();
                            MessageBox.Show("Поставка оформлена! Склад обновлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            lstSupplyDraft.Items.Clear();
                            currentSupplyTotal = 0;
                            lblSupplyTotal.Text = "0 р.";
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Ошибка поставки: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void LoadStock()
        {
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    // Добавляем скрытые колонки "type" и "id"
                    string sql = @"
                SELECT 'accessory' AS type, accessory_id AS id, 'Товар/Услуга' AS ""Тип"", name AS ""Название"", stock_quantity AS ""Остаток"", sale_price AS ""Цена продажи""
                FROM accessories
                UNION ALL
                SELECT 'part' AS type, part_id AS id, 'Запчасть' AS ""Тип"", name AS ""Название"", stock_quantity AS ""Остаток"", NULL AS ""Цена продажи""
                FROM parts
                ORDER BY ""Тип"", ""Название""";

                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dgvStock.DataSource = dt;

                    // Скрываем технические колонки (type и id нам нужны в коде, но не нужны глазам)
                    if (dgvStock.Columns["type"] != null) dgvStock.Columns["type"].Visible = false;
                    if (dgvStock.Columns["id"] != null) dgvStock.Columns["id"].Visible = false;

                    // Настройка ширины
                    if (dgvStock.Columns["Название"] != null)
                        dgvStock.Columns["Название"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка склада: " + ex.Message);
            }
        }

        private void btnRefreshStock_Click(object sender, EventArgs e)
        {
            LoadStock();
        }

        private void btnSetPhoto_Click(object sender, EventArgs e)
        {
            // 1. Проверяем, выбрана ли строка
            if (dgvStock.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите товар из списка!");
                return;
            }

            // 2. Получаем данные из скрытых колонок
            string type = dgvStock.SelectedRows[0].Cells["type"].Value.ToString();
            int id = Convert.ToInt32(dgvStock.SelectedRows[0].Cells["id"].Value);

            // У запчастей (parts) нет поля photo_url в базе, поэтому фото можно ставить только аксессуарам
            if (type == "part")
            {
                MessageBox.Show("Для запчастей фото не предусмотрено (только для товаров витрины).");
                return;
            }

            // 3. Выбираем файл
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Картинки|*.jpg;*.png;*.jpeg";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // 4. Копируем файл в папку Photos
                    string folder = Path.Combine(Application.StartupPath, "Photos");
                    if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);

                    string ext = Path.GetExtension(ofd.FileName);
                    string newFileName = $"item_{id}_{Guid.NewGuid()}{ext}"; // Уникальное имя
                    string savedPath = Path.Combine(folder, newFileName);

                    File.Copy(ofd.FileName, savedPath);

                    // 5. Сохраняем путь в БД
                    using (var conn = Database.GetConnection())
                    {
                        conn.Open();
                        string sql = "UPDATE accessories SET photo_url = @path WHERE accessory_id = @id";

                        using (var cmd = new NpgsqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("path", savedPath);
                            cmd.Parameters.AddWithValue("id", id);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Фото успешно добавлено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения фото: " + ex.Message);
                }
            }
        }
    }
}
