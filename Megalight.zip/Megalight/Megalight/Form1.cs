﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Megalight
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string passwordInput = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(passwordInput))
            {
                MessageBox.Show("Введите логин и пароль!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();

                    // Превращаем введенный пароль в ХЕШ, чтобы сравнить с базой
                    string passwordHash = HashPassword(passwordInput);

                    // ВНИМАНИЕ!
                    // Если ты не обновлял пароль админа в базе на хеш, этот код не пустит тебя со старым паролем "admin".
                    // В таком случае временно используй: password_hash = @p (и передавай passwordInput без хеша).

                    string sql = "SELECT role, fio FROM employees WHERE login = @u AND password_hash = @p";

                    using (var cmd = new NpgsqlCommand(sql, conn)) // <--- Вот здесь создается 'cmd'
                    {
                        cmd.Parameters.AddWithValue("u", login);
                        cmd.Parameters.AddWithValue("p", passwordHash); // Передаем хеш

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string role = reader["role"].ToString();
                                string fio = reader["fio"].ToString();

                                MessageBox.Show($"Добро пожаловать, {fio}!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                OpenRoleForm(role);
                            }
                            else
                            {
                                MessageBox.Show("Неверный логин или пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения: " + ex.Message);
            }

        }

        private void OpenRoleForm(string role)
        {
            // Скрываем форму входа
            this.Hide();

            Form nextForm = null;

            switch (role)
            {
                case "manager":
                    nextForm = new ManagerForm();
                    break;
                case "master":
                    nextForm = new MasterForm();
                    break;
                case "admin":
                    nextForm = new AdminForm();
                    break;
                default:
                    MessageBox.Show("У этого сотрудника нет назначенной роли!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.Show(); // Возвращаем окно входа
                    return;
            }
            // Открываем форму и подписываемся на её закрытие
            if (nextForm != null)
            {
                nextForm.ShowDialog(); // ShowDialog блокирует код здесь, пока окно не закроют
                this.Close(); // Когда главное окно закрыли — закрываем программу целиком
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
