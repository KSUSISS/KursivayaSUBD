﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Megalight
{
    public partial class BuybackForm : Form
    {
       
        private string selectedPhotoPath = null;

        public BuybackForm()
        {
            InitializeComponent();
         
            if (cmbCondition.Items.Count > 0)
                cmbCondition.SelectedIndex = 0;
        }

        private void btnUploadPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Изображения|*.jpg;*.png;*.jpeg";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                // Показываем картинку на форме
                pbDevicePhoto.Image = Image.FromFile(ofd.FileName);
                // Запоминаем путь, откуда взяли файл
                selectedPhotoPath = ofd.FileName;
            }
        }

        private void btnConfirmBuy_Click(object sender, EventArgs e)
        {
            // Проверка заполнения
            if (string.IsNullOrWhiteSpace(txtClientFio.Text) ||
                string.IsNullOrWhiteSpace(txtPassport.Text) ||
                string.IsNullOrWhiteSpace(txtModel.Text) ||
                string.IsNullOrWhiteSpace(txtImei.Text))
            {
                MessageBox.Show("Заполните все поля!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    using (var transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            // --- 1. КЛИЕНТ ---
                            string sqlClient = "INSERT INTO clients (fio, passport, phone) VALUES (@fio, @pass, @phone) RETURNING client_id";
                            int clientId;
                            using (var cmd = new NpgsqlCommand(sqlClient, conn))
                            {
                                cmd.Transaction = transaction;
                                cmd.Parameters.AddWithValue("fio", txtClientFio.Text.Trim());
                                cmd.Parameters.AddWithValue("pass", txtPassport.Text.Trim());
                                cmd.Parameters.AddWithValue("phone", txtPhone.Text.Trim());
                                clientId = (int)cmd.ExecuteScalar();
                            }

                            // --- 2. СТАТУС ТЕЛЕФОНА ---
                            // ВАЖНО: Смотрим на текст, а не только на индекс, чтобы не ошибиться
                            string status = "in_stock";
                            string selectedText = cmbCondition.Text.ToLower(); // Берем текст из выпадающего списка

                            // Логика: Если в тексте есть "отлично" -> продажа. Иначе -> ремонт.
                            if (selectedText.Contains("отлично") || selectedText.Contains("продажу"))
                            {
                                status = "ready_for_sale";
                            }
                            else
                            {
                                // Всё остальное (потертости, разбит экран) считаем поломкой
                                status = "on_repair";
                            }

                            // --- 3. ФОТО ---
                            string savedPhotoUrl = null;
                            if (selectedPhotoPath != null)
                            {
                                string folder = Path.Combine(Application.StartupPath, "Photos");
                                if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
                                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(selectedPhotoPath);
                                savedPhotoUrl = Path.Combine(folder, fileName);
                                File.Copy(selectedPhotoPath, savedPhotoUrl);
                            }

                            // --- 4. ДОБАВЛЕНИЕ УСТРОЙСТВА ---
                            string sqlDevice = @"
                        INSERT INTO devices (model, imei, status, intake_price, sale_price, client_id, photo_url) 
                        VALUES (@model, @imei, @status::device_status, @intake, @sale, @cli, @photo)
                        RETURNING device_id";

                            int newDeviceId;

                            using (var cmd = new NpgsqlCommand(sqlDevice, conn))
                            {
                                cmd.Transaction = transaction;
                                cmd.Parameters.AddWithValue("model", txtModel.Text.Trim());
                                cmd.Parameters.AddWithValue("imei", txtImei.Text.Trim());
                                cmd.Parameters.AddWithValue("status", status);
                                cmd.Parameters.AddWithValue("intake", numPrice.Value);

                                // Если ремонт - цена продажи NULL, если продажа - наценка
                                if (status == "on_repair")
                                    cmd.Parameters.AddWithValue("sale", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("sale", numPrice.Value * 1.3m);

                                cmd.Parameters.AddWithValue("cli", clientId);

                                if (savedPhotoUrl != null) cmd.Parameters.AddWithValue("photo", savedPhotoUrl);
                                else cmd.Parameters.AddWithValue("photo", DBNull.Value);

                                newDeviceId = (int)cmd.ExecuteScalar();
                            }

                            // --- 5. СОЗДАНИЕ РЕМОНТА (САМОЕ ГЛАВНОЕ) ---
                            if (status == "on_repair")
                            {
                                // Добавляем запись в internal_repairs
                                // employee_id ставим NULL, так как мастер еще не взял заказ
                                string sqlRepair = @"
                            INSERT INTO internal_repairs (device_id, employee_id, start_date, status, problem_description, labor_price)
                            VALUES (@did, NULL, NOW(), 'in_process', @prob, 0)";

                                using (var cmdRep = new NpgsqlCommand(sqlRepair, conn))
                                {
                                    cmdRep.Transaction = transaction;
                                    cmdRep.Parameters.AddWithValue("did", newDeviceId);
                                    // Описание проблемы берем из названия состояния (например, "Разбит экран")
                                    cmdRep.Parameters.AddWithValue("prob", "Скупка: " + cmbCondition.Text);
                                    cmdRep.ExecuteNonQuery();
                                }
                            }

                            transaction.Commit();

                           
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Ошибка: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка БД: " + ex.Message);
            }

           

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
