﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Megalight
{
    public partial class ProductCard : UserControl
    {
        public int Id { get; set; }
        public string ProductType { get; set; }
     
        public decimal Price { get; set; }
        public string Title { get; set; }

        public event EventHandler CardClicked;

        public ProductCard()
        {
            InitializeComponent();

            this.Click += (s, e) => CardClicked?.Invoke(this, e);
            pbImage.Click += (s, e) => CardClicked?.Invoke(this, e);
            lblName.Click += (s, e) => CardClicked?.Invoke(this, e);
            lblPrice.Click += (s, e) => CardClicked?.Invoke(this, e);
        }

        public void SetData(int id, string type, string name, decimal price, string photoUrl)
        {
            this.Id = id;
            this.ProductType = type;
            this.Title = name;
            this.Price = price;
            lblName.Text = name;
            lblPrice.Text = $"{price:C0}";

            if (!string.IsNullOrEmpty(photoUrl) && File.Exists(photoUrl))
            {
                pbImage.Image = Image.FromFile(photoUrl);
            }
            else
            {
                // Если фото нет, можно загрузить заглушку из ресурсов или оставить пустым
                pbImage.BackColor = Color.LightGray;
            }
        }
        private void ProductCard_Click(object sender, EventArgs e)
        {

        }
   



    }
}
