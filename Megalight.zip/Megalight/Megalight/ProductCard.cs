﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Megalight
{
    public partial class ProductCard : UserControl
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public decimal Price { get; set; }

        public ProductCard()
        {
            InitializeComponent();
            this.Click += ProductCard_Click;
            pbImage.Click += (s, e) => this.OnClick(e);
            lblName.Click += (s, e) => this.OnClick(e);
        }
        
        private void ProductCard_Click(object sender, EventArgs e)
        {

        }
   



    }
}
