﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace Megalight
{
    public partial class ManagerForm : Form
    {
        
        private bool isDragging = false;
        private Point startPoint = new Point(0, 0);

        private enum CatalogMode
        {
            Devices,
            Accessories,
            Services
        }

        private CatalogMode currentMode = CatalogMode.Devices;
        private decimal currentTotalSum = 0;

        public ManagerForm()
        {
            InitializeComponent();
        }

     


        private void btnOpenBuyback_Click(object sender, EventArgs e)
        {
            BuybackForm form = new BuybackForm();
            form.ShowDialog();
            LoadDevices();
        }

        private void ManagerForm_Load(object sender, EventArgs e)
        {
            LoadDevices();

        }

        private void ClearCatalog()
        {
            flowPanelCatalog.Controls.Clear();
        }

        private void Product_Clicked(object sender, EventArgs e)
        {
            ProductCard card = (ProductCard)sender;

            CartItem item = new CartItem
            {
                Id = card.Id,
                Type = card.ProductType,
                Name = card.Title,
                Price = card.Price
            };

            lstCart.Items.Add(item);

            currentTotalSum += card.Price;
            lblTotalSum.Text = $"Итого: {currentTotalSum:C0}";
        }

        private void LoadServices(string searchText = "")
        {
            ClearCatalog();
            lblHeaderTitle.Text = "Каталог: Услуги";
            currentMode = CatalogMode.Services; // Запоминаем режим

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    string sql = @"
                SELECT a.accessory_id, a.name, a.sale_price, a.photo_url 
                FROM accessories a
                JOIN categories c ON a.category_id = c.category_id
                WHERE a.stock_quantity > 0 AND c.name ILIKE '%Услуг%'";

                    if (!string.IsNullOrWhiteSpace(searchText))
                    {
                        sql += " AND a.name ILIKE @search";
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        if (!string.IsNullOrWhiteSpace(searchText))
                        {
                            cmd.Parameters.AddWithValue("search", $"%{searchText}%");
                        }

                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ProductCard card = new ProductCard();
                                int id = Convert.ToInt32(reader["accessory_id"]);
                                string name = reader["name"].ToString();
                                decimal price = Convert.ToDecimal(reader["sale_price"]);

                                string photo = "";
                                if (reader["photo_url"] != DBNull.Value) photo = reader["photo_url"].ToString();

                                card.SetData(id, "accessory", name, price, photo);
                                card.CardClicked += Product_Clicked;
                                flowPanelCatalog.Controls.Add(card);
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }
        }

        private void LoadDevices(string searchText = "")
        {
            ClearCatalog();
            lblHeaderTitle.Text = "Каталог: Смартфоны (Б/У)";
            currentMode = CatalogMode.Devices; // Запоминаем режим

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    // SQL с фильтром поиска
                    string sql = "SELECT device_id, model, sale_price, photo_url FROM devices WHERE status = 'ready_for_sale'";

                    // Если в поиске что-то есть, добавляем условие ILIKE (поиск без учета регистра)
                    if (!string.IsNullOrWhiteSpace(searchText))
                    {
                        sql += " AND model ILIKE @search";
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        // Если ищем, добавляем параметр с процентами %текст%
                        if (!string.IsNullOrWhiteSpace(searchText))
                        {
                            cmd.Parameters.AddWithValue("search", $"%{searchText}%");
                        }

                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ProductCard card = new ProductCard();
                                int id = Convert.ToInt32(reader["device_id"]);
                                string model = reader["model"].ToString();

                                decimal price = 0;
                                if (reader["sale_price"] != DBNull.Value) price = Convert.ToDecimal(reader["sale_price"]);

                                string photo = "";
                                if (reader["photo_url"] != DBNull.Value) photo = reader["photo_url"].ToString();

                                card.SetData(id, "device", model, price, photo);
                                card.CardClicked += Product_Clicked;
                                flowPanelCatalog.Controls.Add(card);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        

        private void LoadAccessories(string searchText = "")
        {
            ClearCatalog();
            lblHeaderTitle.Text = "Каталог: Аксессуары";
            currentMode = CatalogMode.Accessories; // Запоминаем режим

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    // Исключаем услуги (Услуги - это категория 5, или проверяем по имени категории)
                    // Лучше делать через JOIN, как мы договаривались: Ищем всё, КРОМЕ услуг
                    string sql = @"
                SELECT a.accessory_id, a.name, a.sale_price, a.photo_url 
                FROM accessories a
                JOIN categories c ON a.category_id = c.category_id
                WHERE a.stock_quantity > 0 AND c.name NOT ILIKE '%Услуг%'";

                    if (!string.IsNullOrWhiteSpace(searchText))
                    {
                        sql += " AND a.name ILIKE @search";
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        if (!string.IsNullOrWhiteSpace(searchText))
                        {
                            cmd.Parameters.AddWithValue("search", $"%{searchText}%");
                        }

                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ProductCard card = new ProductCard();
                                int id = Convert.ToInt32(reader["accessory_id"]);
                                string name = reader["name"].ToString();
                                decimal price = Convert.ToDecimal(reader["sale_price"]);

                                string photo = "";
                                if (reader["photo_url"] != DBNull.Value) photo = reader["photo_url"].ToString();

                                card.SetData(id, "accessory", name, price, photo);
                                card.CardClicked += Product_Clicked;
                                flowPanelCatalog.Controls.Add(card);
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }
        }

        public class CartItem
        {
            public int Id { get; set; }
            public string Type { get; set; } // "device" или "accessory"
            public string Name { get; set; }
            public decimal Price { get; set; }

            public override string ToString()
            {
                return $"{Name} — {Price:N0} р.";
            }
        }

        private void btnCatDevices_Click(object sender, EventArgs e)
        {
            LoadDevices();
            txtSearch.Clear();
        }

        private void btnCatAccessories_Click(object sender, EventArgs e)
        {
            LoadAccessories();
            txtSearch.Clear();
        }

        private void btnClearCart_Click(object sender, EventArgs e)
        {
            lstCart.Items.Clear();
            currentTotalSum = 0;
            lblTotalSum.Text = "Итого: 0 р.";
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if (lstCart.Items.Count == 0)
            {
                MessageBox.Show("Корзина пуста!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    using (var transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            string sqlSale = "INSERT INTO sales (employee_id, client_id, total_amount) VALUES (@emp, @cli, @sum) RETURNING sale_id";

                            int saleId;
                            using (var cmd = new NpgsqlCommand(sqlSale, conn))
                            {
                                cmd.Transaction = transaction;
                                cmd.Parameters.AddWithValue("emp", 2);
                                cmd.Parameters.AddWithValue("cli", DBNull.Value);
                                cmd.Parameters.AddWithValue("sum", currentTotalSum);

                                saleId = (int)cmd.ExecuteScalar();
                            }

                            foreach (CartItem item in lstCart.Items)
                            {
                                string sqlItem = "";

                                if (item.Type == "device")
                                {
                                    sqlItem = "INSERT INTO sale_items (sale_id, device_id, quantity, price_at_moment) VALUES (@sid, @did, 1, @price)";

                                    string sqlUpd = "UPDATE devices SET status = 'sold' WHERE device_id = @did";
                                    using (var cmdUpd = new NpgsqlCommand(sqlUpd, conn))
                                    {
                                        cmdUpd.Transaction = transaction;
                                        cmdUpd.Parameters.AddWithValue("did", item.Id);
                                        cmdUpd.ExecuteNonQuery();
                                    }
                                }
                                else
                                {
                                    sqlItem = "INSERT INTO sale_items (sale_id, accessory_id, quantity, price_at_moment) VALUES (@sid, @aid, 1, @price)";

                                    string sqlStock = "UPDATE accessories SET stock_quantity = stock_quantity - 1 WHERE accessory_id = @aid";
                                    using (var cmdStock = new NpgsqlCommand(sqlStock, conn))
                                    {
                                        cmdStock.Transaction = transaction;
                                        cmdStock.Parameters.AddWithValue("aid", item.Id);
                                        cmdStock.ExecuteNonQuery();
                                    }
                                }

                                using (var cmdItem = new NpgsqlCommand(sqlItem, conn))
                                {
                                    cmdItem.Transaction = transaction;
                                    cmdItem.Parameters.AddWithValue("sid", saleId);
                                    cmdItem.Parameters.AddWithValue("price", item.Price);

                                    if (item.Type == "device")
                                        cmdItem.Parameters.AddWithValue("did", item.Id);
                                    else
                                        cmdItem.Parameters.AddWithValue("aid", item.Id);

                                    cmdItem.ExecuteNonQuery();
                                }
                            }

                            transaction.Commit();
                            MessageBox.Show("Продажа успешно оформлена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            btnClearCart_Click(null, null);
                            LoadDevices();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Ошибка транзакции: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения: " + ex.Message);
            }
        }

        private void btnCatServices_Click(object sender, EventArgs e)
        {
            LoadServices();
            txtSearch.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string text = txtSearch.Text.Trim();
            switch (currentMode)
            {
                case CatalogMode.Devices: LoadDevices(text); break;
                case CatalogMode.Accessories: LoadAccessories(text); break;
                case CatalogMode.Services: LoadServices(text); break;
            }
        }
    }
}
