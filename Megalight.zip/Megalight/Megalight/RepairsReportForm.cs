﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Megalight
{
    public partial class RepairsReportForm : Form
    {
        public RepairsReportForm()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    // Выбираем только завершенные ремонты (status = 'ready')
                    string sql = @"
                        SELECT 
                            d.model AS ""Модель"",
                            e.fio AS ""Мастер"",
                            r.end_date AS ""Дата завершения"",
                            r.problem_description AS ""Была проблема"",
                            r.report AS ""Отчет о работе"",
                            r.labor_price AS ""Цена работы""
                        FROM internal_repairs r
                        JOIN devices d ON r.device_id = d.device_id
                        LEFT JOIN employees e ON r.employee_id = e.employee_id
                        WHERE r.status = 'ready' 
                          AND r.end_date BETWEEN @s AND @e
                        ORDER BY r.end_date DESC";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        // Берем начало и конец дня
                        cmd.Parameters.AddWithValue("s", dtpStart.Value.Date);
                        cmd.Parameters.AddWithValue("e", dtpEnd.Value.Date.AddDays(1).AddSeconds(-1));

                        NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        dgvRepairsHistory.DataSource = dt;

                        // Красота
                        if (dgvRepairsHistory.Columns["Отчет о работе"] != null)
                            dgvRepairsHistory.Columns["Отчет о работе"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }
        private void DesignTable()
        {
            // 1. Общие настройки
            dgvRepairsHistory.BorderStyle = BorderStyle.None;
            dgvRepairsHistory.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(238, 239, 249); // Зебра
            dgvRepairsHistory.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvRepairsHistory.DefaultCellStyle.SelectionBackColor = Color.DarkTurquoise;
            dgvRepairsHistory.DefaultCellStyle.SelectionForeColor = Color.WhiteSmoke;
            dgvRepairsHistory.BackgroundColor = Color.White;

            // 2. Шрифт покрупнее
            dgvRepairsHistory.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            dgvRepairsHistory.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11, FontStyle.Bold);

            // 3. САМОЕ ГЛАВНОЕ: Перенос текста
            dgvRepairsHistory.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells; // Высота строки подстраивается
            dgvRepairsHistory.DefaultCellStyle.WrapMode = DataGridViewTriState.True;    // Текст переносится на новую строку

            // 4. Настройка ширины колонок
            if (dgvRepairsHistory.Columns.Count > 0)
            {
                // Фиксированные колонки
                dgvRepairsHistory.Columns["Дата"].Width = 100;
                dgvRepairsHistory.Columns["Цена"].Width = 100;
                dgvRepairsHistory.Columns["Цена"].DefaultCellStyle.Format = "C0"; // Формат валюты (₽)
                dgvRepairsHistory.Columns["Мастер"].Width = 150;
                dgvRepairsHistory.Columns["Модель"].Width = 150;

                // Колонки с текстом растягиваем на всё место
                dgvRepairsHistory.Columns["Проблема"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dgvRepairsHistory.Columns["Отчет мастера"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                // Делаем Отчет мастера чуть шире Проблемы (FillWeight)
                dgvRepairsHistory.Columns["Отчет мастера"].FillWeight = 60;
                dgvRepairsHistory.Columns["Проблема"].FillWeight = 40;
            }
        }
    }
}
