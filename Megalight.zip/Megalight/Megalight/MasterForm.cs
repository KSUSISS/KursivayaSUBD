﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Megalight
{
    public partial class MasterForm : Form
    {
        
       
        private int currentRepairId = -1;
        private int currentDeviceId = -1;

        public MasterForm()
        {
            InitializeComponent();
        }
       
       

        public void LoadRepairTasks()
        {
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    // Выбираем ремонты. 
                    // ВАЖНО: Если в базе статус отличается хоть на букву, запись не появится.
                    string sql = @"
                        SELECT r.repair_id, r.device_id, d.model, r.problem_description, d.photo_url, r.start_date
                        FROM internal_repairs r
                        JOIN devices d ON r.device_id = d.device_id
                        WHERE r.status = 'in_process'";

                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dgvRepairTasks.AutoGenerateColumns = true; // Пусть таблица сама создаст колонки
                    dgvRepairTasks.DataSource = dt;

                    // Скрываем лишнее
                    if (dgvRepairTasks.Columns["repair_id"] != null) dgvRepairTasks.Columns["repair_id"].Visible = false;
                    if (dgvRepairTasks.Columns["device_id"] != null) dgvRepairTasks.Columns["device_id"].Visible = false;
                    if (dgvRepairTasks.Columns["photo_url"] != null) dgvRepairTasks.Columns["photo_url"].Visible = false;

                    // Заголовки
                    if (dgvRepairTasks.Columns["model"] != null) dgvRepairTasks.Columns["model"].HeaderText = "Модель";
                    if (dgvRepairTasks.Columns["problem_description"] != null) dgvRepairTasks.Columns["problem_description"].HeaderText = "Проблема";
                    if (dgvRepairTasks.Columns["start_date"] != null) dgvRepairTasks.Columns["start_date"].HeaderText = "Дата";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки задач: " + ex.Message);
            }
        }

        

        private void LoadPartsCombo()
        {
            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    // Убрал условие stock_quantity > 0, чтобы ты видел ВСЕ запчасти.
                    // Если запчасти нет, мы скажем об этом при попытке добавить.
                    string sql = "SELECT part_id, name, stock_quantity FROM parts ORDER BY name";

                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Настраиваем отображение: показываем Имя, храним ID
                    cmbParts.DataSource = dt;
                    cmbParts.DisplayMember = "name";
                    cmbParts.ValueMember = "part_id";
                    cmbParts.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки запчастей: " + ex.Message);
            }
        }

        private void LoadUsedParts()
        {
            if (currentRepairId == -1) return;

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    // Считаем общую сумму запчастей и выводим список
                    string sql = @"
                SELECT p.name, rc.quantity, p.purchase_price, (rc.quantity * p.purchase_price) as total_sum
                FROM repair_consumables rc
                JOIN parts p ON rc.part_id = p.part_id
                WHERE rc.repair_id = @rid";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("rid", currentRepairId);
                        NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        // Очистка и привязка
                        dgvUsedParts.DataSource = null;
                        dgvUsedParts.Columns.Clear();
                        dgvUsedParts.AutoGenerateColumns = true;
                        dgvUsedParts.DataSource = dt;

                        // Наводим красоту
                        if (dgvUsedParts.Columns["name"] != null) dgvUsedParts.Columns["name"].HeaderText = "Запчасть";
                        if (dgvUsedParts.Columns["quantity"] != null) dgvUsedParts.Columns["quantity"].HeaderText = "Кол-во";
                        if (dgvUsedParts.Columns["purchase_price"] != null) dgvUsedParts.Columns["purchase_price"].HeaderText = "Цена";
                        if (dgvUsedParts.Columns["total_sum"] != null) dgvUsedParts.Columns["total_sum"].HeaderText = "Сумма";
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnAddPart_Click(object sender, EventArgs e)
        {
            if (currentRepairId == -1)
            {
                MessageBox.Show("Сначала выберите ремонт слева!");
                return;
            }
            if (cmbParts.SelectedValue == null)
            {
                MessageBox.Show("Выберите запчасть!");
                return;
            }

            // Получаем ID сразу из ValueMember (никакого парсинга строк!)
            int partId = Convert.ToInt32(cmbParts.SelectedValue);

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    using (var transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            // 1. Проверяем наличие и списываем
                            string sqlStock = "UPDATE parts SET stock_quantity = stock_quantity - 1 WHERE part_id = @pid AND stock_quantity > 0";
                            using (var cmd = new NpgsqlCommand(sqlStock, conn))
                            {
                                cmd.Transaction = transaction;
                                cmd.Parameters.AddWithValue("pid", partId);
                                int rows = cmd.ExecuteNonQuery();
                                if (rows == 0)
                                {
                                    // Если 0 строк обновлено - значит товара нет
                                    transaction.Rollback();
                                    MessageBox.Show("Этой запчасти нет в наличии (кол-во = 0)!");
                                    return;
                                }
                            }

                            // 2. Добавляем в ремонт
                            // Если такая запчасть уже есть в ремонте, увеличиваем кол-во (ON CONFLICT... DO UPDATE)
                            // Но для простоты курсовой можно просто INSERT новой строкой, если нет уникального ключа
                            string sqlAdd = "INSERT INTO repair_consumables (repair_id, part_id, quantity) VALUES (@rid, @pid, 1)";
                            using (var cmd = new NpgsqlCommand(sqlAdd, conn))
                            {
                                cmd.Transaction = transaction;
                                cmd.Parameters.AddWithValue("rid", currentRepairId);
                                cmd.Parameters.AddWithValue("pid", partId);
                                cmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            LoadUsedParts(); // Обновляем таблицу внизу
                            LoadPartsCombo(); // Обновляем список (чтобы кол-во пересчиталось, если мы его выводим)
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Ошибка: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            if (currentRepairId == -1)
            {
                MessageBox.Show("Выберите ремонт!");
                return;
            }

            // Фиксированная цена работы
            decimal fixedLaborPrice = 5000;

            var confirm = MessageBox.Show(
                $"Завершить ремонт?\n\nБудет установлена фиксированная стоимость работы: {fixedLaborPrice} ₽\n" +
                "Телефон автоматически появится в продаже с наценкой.",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes) return;

            try
            {
                using (var conn = Database.GetConnection())
                {
                    conn.Open();
                    using (var transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            // 1. Закрываем ремонт (в таблице internal_repairs)
                            // Ставим статус 'ready' и фиксированную цену работы 5000
                            string sqlRepair = @"
                        UPDATE internal_repairs 
                        SET status = 'ready', end_date = NOW(), report = @rep, labor_price = @labor 
                        WHERE repair_id = @rid";

                            using (var cmd = new NpgsqlCommand(sqlRepair, conn))
                            {
                                cmd.Transaction = transaction;
                                cmd.Parameters.AddWithValue("rep", txtWorkResult.Text); // Отчет мастера
                                cmd.Parameters.AddWithValue("labor", fixedLaborPrice);  // 5000
                                cmd.Parameters.AddWithValue("rid", currentRepairId);
                                cmd.ExecuteNonQuery();
                            }

                            // 2. Обновляем телефон (в таблице devices)
                            // Ставим статус 'ready_for_sale'
                            // Записываем labor_costs = 5000
                            // И СРАЗУ СЧИТАЕМ ЦЕНУ ПРОДАЖИ: (Купили + Запчасти + 5000)
                            string sqlDevice = @"
                        UPDATE devices 
                        SET status = 'ready_for_sale', 
                            labor_costs = @labor,
                            sale_price = (COALESCE(intake_price, 0) + COALESCE(repair_costs, 0) + @labor)
                        WHERE device_id = @did";

                            using (var cmd = new NpgsqlCommand(sqlDevice, conn))
                            {
                                cmd.Transaction = transaction;
                                cmd.Parameters.AddWithValue("labor", fixedLaborPrice); // 5000
                                cmd.Parameters.AddWithValue("did", currentDeviceId);
                                cmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            MessageBox.Show($"Ремонт завершен!\nТелефон выставлен на продажу.", "Успех");

                            // Очистка интерфейса
                            lblDeviceModel.Text = "Выберите устройство...";
                            txtProblemDesc.Clear();
                            txtWorkResult.Clear();
                            pbDevicePhoto.Image = null;
                            dgvUsedParts.DataSource = null;
                            currentRepairId = -1;

                            // Обновляем список (телефон должен исчезнуть)
                            LoadRepairTasks();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Ошибка завершения: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadRepairTasks();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dgvRepairTasks_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dgvRepairTasks.Rows[e.RowIndex];

            // Защита от пустых строк
            if (row.Cells["repair_id"].Value == DBNull.Value) return;

            currentRepairId = Convert.ToInt32(row.Cells["repair_id"].Value);
            currentDeviceId = Convert.ToInt32(row.Cells["device_id"].Value);

            string model = row.Cells["model"].Value.ToString();
            string problem = row.Cells["problem_description"].Value.ToString();

            string photoUrl = "";
            if (row.Cells["photo_url"].Value != DBNull.Value)
                photoUrl = row.Cells["photo_url"].Value.ToString();

            lblDeviceModel.Text = model;
            txtProblemDesc.Text = problem;

            if (!string.IsNullOrEmpty(photoUrl) && File.Exists(photoUrl))
                pbDevicePhoto.Image = Image.FromFile(photoUrl);
            else
                pbDevicePhoto.Image = null;

            LoadUsedParts();
        }

        private void MasterForm_Load(object sender, EventArgs e)
        {
            LoadRepairTasks();
            // Грузим список ремонтов
            LoadPartsCombo();
        }

        private void btnOpenRepairReport_Click(object sender, EventArgs e)
        {
            RepairsReportForm form = new RepairsReportForm();
            form.ShowDialog();
        }
    }
    
}
