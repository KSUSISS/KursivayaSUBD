﻿namespace Megalight
{
    partial class MasterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlSidebar = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgvRepairTasks = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnFinish = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numLaborPrice = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.txtWorkResult = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbSpareParts = new System.Windows.Forms.GroupBox();
            this.cmbParts = new System.Windows.Forms.ComboBox();
            this.dgvUsedParts = new System.Windows.Forms.DataGridView();
            this.btnAddPart = new System.Windows.Forms.Button();
            this.txtProblemDesc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pbDevicePhoto = new System.Windows.Forms.PictureBox();
            this.lblDeviceModel = new System.Windows.Forms.Label();
            this.btnOpenRepairReport = new System.Windows.Forms.Button();
            this.pnlSidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRepairTasks)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLaborPrice)).BeginInit();
            this.cmbSpareParts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsedParts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDevicePhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlSidebar
            // 
            this.pnlSidebar.Controls.Add(this.btnOpenRepairReport);
            this.pnlSidebar.Controls.Add(this.btnExit);
            this.pnlSidebar.Controls.Add(this.btnRefresh);
            this.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSidebar.Location = new System.Drawing.Point(0, 0);
            this.pnlSidebar.Name = "pnlSidebar";
            this.pnlSidebar.Size = new System.Drawing.Size(100, 649);
            this.pnlSidebar.TabIndex = 0;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(12, 410);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 28);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(3, 12);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(94, 40);
            this.btnRefresh.TabIndex = 0;
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(100, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvRepairTasks);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel2.Controls.Add(this.cmbSpareParts);
            this.splitContainer1.Panel2.Controls.Add(this.txtProblemDesc);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.pbDevicePhoto);
            this.splitContainer1.Panel2.Controls.Add(this.lblDeviceModel);
            this.splitContainer1.Size = new System.Drawing.Size(1370, 649);
            this.splitContainer1.SplitterDistance = 456;
            this.splitContainer1.TabIndex = 1;
            // 
            // dgvRepairTasks
            // 
            this.dgvRepairTasks.AllowUserToAddRows = false;
            this.dgvRepairTasks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRepairTasks.Location = new System.Drawing.Point(10, 33);
            this.dgvRepairTasks.Name = "dgvRepairTasks";
            this.dgvRepairTasks.ReadOnly = true;
            this.dgvRepairTasks.RowHeadersWidth = 51;
            this.dgvRepairTasks.RowTemplate.Height = 24;
            this.dgvRepairTasks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRepairTasks.Size = new System.Drawing.Size(429, 405);
            this.dgvRepairTasks.TabIndex = 1;
            this.dgvRepairTasks.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRepairTasks_CellClick_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Очередь ремонта";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnFinish);
            this.groupBox2.Location = new System.Drawing.Point(449, 558);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(433, 88);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            // 
            // btnFinish
            // 
            this.btnFinish.BackColor = System.Drawing.Color.Lime;
            this.btnFinish.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnFinish.Location = new System.Drawing.Point(3, 11);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(427, 74);
            this.btnFinish.TabIndex = 0;
            this.btnFinish.Text = "ЗАВЕРШИТЬ РЕМОНТ (ГОТОВ К ПРОДАЖЕ)";
            this.btnFinish.UseVisualStyleBackColor = false;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numLaborPrice);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtWorkResult);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(10, 417);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(433, 220);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Работа мастера";
            // 
            // numLaborPrice
            // 
            this.numLaborPrice.Location = new System.Drawing.Point(221, 42);
            this.numLaborPrice.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numLaborPrice.Name = "numLaborPrice";
            this.numLaborPrice.Size = new System.Drawing.Size(196, 22);
            this.numLaborPrice.TabIndex = 3;
            this.numLaborPrice.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(218, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Стоимость работы(Руб.)";
            // 
            // txtWorkResult
            // 
            this.txtWorkResult.Location = new System.Drawing.Point(10, 42);
            this.txtWorkResult.Multiline = true;
            this.txtWorkResult.Name = "txtWorkResult";
            this.txtWorkResult.Size = new System.Drawing.Size(196, 172);
            this.txtWorkResult.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(199, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Отчёт о проделанной работе";
            // 
            // cmbSpareParts
            // 
            this.cmbSpareParts.Controls.Add(this.cmbParts);
            this.cmbSpareParts.Controls.Add(this.dgvUsedParts);
            this.cmbSpareParts.Controls.Add(this.btnAddPart);
            this.cmbSpareParts.Location = new System.Drawing.Point(356, 13);
            this.cmbSpareParts.Name = "cmbSpareParts";
            this.cmbSpareParts.Size = new System.Drawing.Size(445, 398);
            this.cmbSpareParts.TabIndex = 4;
            this.cmbSpareParts.TabStop = false;
            this.cmbSpareParts.Text = "Использованные запчасти";
            // 
            // cmbParts
            // 
            this.cmbParts.FormattingEnabled = true;
            this.cmbParts.Location = new System.Drawing.Point(155, 21);
            this.cmbParts.Name = "cmbParts";
            this.cmbParts.Size = new System.Drawing.Size(276, 24);
            this.cmbParts.TabIndex = 2;
            // 
            // dgvUsedParts
            // 
            this.dgvUsedParts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsedParts.Location = new System.Drawing.Point(0, 62);
            this.dgvUsedParts.Name = "dgvUsedParts";
            this.dgvUsedParts.RowHeadersWidth = 51;
            this.dgvUsedParts.RowTemplate.Height = 24;
            this.dgvUsedParts.Size = new System.Drawing.Size(431, 326);
            this.dgvUsedParts.TabIndex = 1;
            // 
            // btnAddPart
            // 
            this.btnAddPart.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAddPart.Location = new System.Drawing.Point(-1, 21);
            this.btnAddPart.Name = "btnAddPart";
            this.btnAddPart.Size = new System.Drawing.Size(72, 34);
            this.btnAddPart.TabIndex = 0;
            this.btnAddPart.Text = "+";
            this.btnAddPart.UseVisualStyleBackColor = true;
            this.btnAddPart.Click += new System.EventHandler(this.btnAddPart_Click);
            // 
            // txtProblemDesc
            // 
            this.txtProblemDesc.Location = new System.Drawing.Point(10, 254);
            this.txtProblemDesc.Multiline = true;
            this.txtProblemDesc.Name = "txtProblemDesc";
            this.txtProblemDesc.ReadOnly = true;
            this.txtProblemDesc.Size = new System.Drawing.Size(330, 50);
            this.txtProblemDesc.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 224);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Неисправность ";
            // 
            // pbDevicePhoto
            // 
            this.pbDevicePhoto.Location = new System.Drawing.Point(10, 49);
            this.pbDevicePhoto.Name = "pbDevicePhoto";
            this.pbDevicePhoto.Size = new System.Drawing.Size(330, 150);
            this.pbDevicePhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbDevicePhoto.TabIndex = 1;
            this.pbDevicePhoto.TabStop = false;
            // 
            // lblDeviceModel
            // 
            this.lblDeviceModel.AutoSize = true;
            this.lblDeviceModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDeviceModel.Location = new System.Drawing.Point(4, 13);
            this.lblDeviceModel.Name = "lblDeviceModel";
            this.lblDeviceModel.Size = new System.Drawing.Size(346, 32);
            this.lblDeviceModel.TabIndex = 0;
            this.lblDeviceModel.Text = "Выберете устройство...";
            // 
            // btnOpenRepairReport
            // 
            this.btnOpenRepairReport.Location = new System.Drawing.Point(3, 91);
            this.btnOpenRepairReport.Name = "btnOpenRepairReport";
            this.btnOpenRepairReport.Size = new System.Drawing.Size(94, 40);
            this.btnOpenRepairReport.TabIndex = 2;
            this.btnOpenRepairReport.Text = "Отчёты";
            this.btnOpenRepairReport.UseVisualStyleBackColor = true;
            this.btnOpenRepairReport.Click += new System.EventHandler(this.btnOpenRepairReport_Click);
            // 
            // MasterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1470, 649);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.pnlSidebar);
            this.Name = "MasterForm";
            this.Text = "Ремонт";
            this.Load += new System.EventHandler(this.MasterForm_Load);
            this.pnlSidebar.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRepairTasks)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLaborPrice)).EndInit();
            this.cmbSpareParts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsedParts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDevicePhoto)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dgvRepairTasks;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtProblemDesc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbDevicePhoto;
        private System.Windows.Forms.Label lblDeviceModel;
        private System.Windows.Forms.GroupBox cmbSpareParts;
        private System.Windows.Forms.DataGridView dgvUsedParts;
        private System.Windows.Forms.Button btnAddPart;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown numLaborPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtWorkResult;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnFinish;
        private System.Windows.Forms.ComboBox cmbParts;
        private System.Windows.Forms.Button btnOpenRepairReport;
    }
}