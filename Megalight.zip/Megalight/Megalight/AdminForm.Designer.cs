﻿namespace Megalight
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.pnlAdminHeader = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnOpenMaster = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOpenManager = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblTotalProfit = new System.Windows.Forms.Label();
            this.chartRevenue = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnShowReport = new System.Windows.Forms.Button();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDeleteUser = new System.Windows.Forms.Button();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.cmbUserRole = new System.Windows.Forms.ComboBox();
            this.txtUserFio = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUserPass = new System.Windows.Forms.TextBox();
            this.txtUserLogin = new System.Windows.Forms.TextBox();
            this.dgvEmployees = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnDeleteCategory = new System.Windows.Forms.Button();
            this.lstCategories = new System.Windows.Forms.ListBox();
            this.btnAddCategory = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNewCategoryName = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dgvSuppliers = new System.Windows.Forms.DataGridView();
            this.pnlSuppliersBottom = new System.Windows.Forms.Panel();
            this.btnDeleteSupplier = new System.Windows.Forms.Button();
            this.btnOpenAddSupplier = new System.Windows.Forms.Button();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.lblSupplyTotal = new System.Windows.Forms.Label();
            this.lstSupplyDraft = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.btnAddSupplyItem = new System.Windows.Forms.Button();
            this.numSupplyPrice = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.numSupplyQty = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbSupplyProduct = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rbPart = new System.Windows.Forms.RadioButton();
            this.rbAccessory = new System.Windows.Forms.RadioButton();
            this.cmbSupplySupplier = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnRestore = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnBackup = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dgvStock = new System.Windows.Forms.DataGridView();
            this.btnRefreshStock = new System.Windows.Forms.Button();
            this.btnSetPhoto = new System.Windows.Forms.Button();
            this.pnlAdminHeader.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartRevenue)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).BeginInit();
            this.pnlSuppliersBottom.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSupplyPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSupplyQty)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStock)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlAdminHeader
            // 
            this.pnlAdminHeader.Controls.Add(this.btnExit);
            this.pnlAdminHeader.Controls.Add(this.btnOpenMaster);
            this.pnlAdminHeader.Controls.Add(this.label1);
            this.pnlAdminHeader.Controls.Add(this.btnOpenManager);
            this.pnlAdminHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlAdminHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlAdminHeader.Name = "pnlAdminHeader";
            this.pnlAdminHeader.Size = new System.Drawing.Size(800, 81);
            this.pnlAdminHeader.TabIndex = 0;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(612, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(176, 33);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnOpenMaster
            // 
            this.btnOpenMaster.Location = new System.Drawing.Point(197, 42);
            this.btnOpenMaster.Name = "btnOpenMaster";
            this.btnOpenMaster.Size = new System.Drawing.Size(176, 33);
            this.btnOpenMaster.TabIndex = 2;
            this.btnOpenMaster.Text = "Открыть \"Мастера\"";
            this.btnOpenMaster.UseVisualStyleBackColor = true;
            this.btnOpenMaster.Click += new System.EventHandler(this.btnOpenMaster_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Панель администратора";
            // 
            // btnOpenManager
            // 
            this.btnOpenManager.Location = new System.Drawing.Point(15, 41);
            this.btnOpenManager.Name = "btnOpenManager";
            this.btnOpenManager.Size = new System.Drawing.Size(176, 33);
            this.btnOpenManager.TabIndex = 0;
            this.btnOpenManager.Text = "Открыть \"Продавца\"";
            this.btnOpenManager.UseVisualStyleBackColor = true;
            this.btnOpenManager.Click += new System.EventHandler(this.btnOpenManager_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 81);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 369);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.Layout += new System.Windows.Forms.LayoutEventHandler(this.tabControl1_Layout);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 340);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Отчёты и Аналитика";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblTotalProfit);
            this.groupBox1.Controls.Add(this.chartRevenue);
            this.groupBox1.Controls.Add(this.btnShowReport);
            this.groupBox1.Controls.Add(this.dtpEnd);
            this.groupBox1.Controls.Add(this.dtpStart);
            this.groupBox1.Location = new System.Drawing.Point(11, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(773, 325);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Параметры";
            // 
            // lblTotalProfit
            // 
            this.lblTotalProfit.AutoSize = true;
            this.lblTotalProfit.Location = new System.Drawing.Point(6, 135);
            this.lblTotalProfit.Name = "lblTotalProfit";
            this.lblTotalProfit.Size = new System.Drawing.Size(217, 16);
            this.lblTotalProfit.TabIndex = 4;
            this.lblTotalProfit.Text = "Общая прибыль за период:... руб";
            // 
            // chartRevenue
            // 
            chartArea2.Name = "ChartArea1";
            this.chartRevenue.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chartRevenue.Legends.Add(legend2);
            this.chartRevenue.Location = new System.Drawing.Point(251, 19);
            this.chartRevenue.Name = "chartRevenue";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chartRevenue.Series.Add(series2);
            this.chartRevenue.Size = new System.Drawing.Size(516, 300);
            this.chartRevenue.TabIndex = 3;
            this.chartRevenue.Text = "chart1";
            // 
            // btnShowReport
            // 
            this.btnShowReport.Location = new System.Drawing.Point(7, 79);
            this.btnShowReport.Name = "btnShowReport";
            this.btnShowReport.Size = new System.Drawing.Size(159, 35);
            this.btnShowReport.TabIndex = 2;
            this.btnShowReport.Text = "Сформировать ";
            this.btnShowReport.UseVisualStyleBackColor = true;
            this.btnShowReport.Click += new System.EventHandler(this.btnShowReport_Click);
            // 
            // dtpEnd
            // 
            this.dtpEnd.Location = new System.Drawing.Point(7, 50);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(200, 22);
            this.dtpEnd.TabIndex = 1;
            // 
            // dtpStart
            // 
            this.dtpStart.Location = new System.Drawing.Point(7, 22);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(200, 22);
            this.dtpStart.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.dgvEmployees);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 340);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Сотрудники";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDeleteUser);
            this.groupBox2.Controls.Add(this.btnAddUser);
            this.groupBox2.Controls.Add(this.cmbUserRole);
            this.groupBox2.Controls.Add(this.txtUserFio);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtUserPass);
            this.groupBox2.Controls.Add(this.txtUserLogin);
            this.groupBox2.Location = new System.Drawing.Point(343, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(441, 310);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Редактирование";
            // 
            // btnDeleteUser
            // 
            this.btnDeleteUser.Location = new System.Drawing.Point(188, 167);
            this.btnDeleteUser.Name = "btnDeleteUser";
            this.btnDeleteUser.Size = new System.Drawing.Size(176, 33);
            this.btnDeleteUser.TabIndex = 9;
            this.btnDeleteUser.Text = "Уволить";
            this.btnDeleteUser.UseVisualStyleBackColor = true;
            this.btnDeleteUser.Click += new System.EventHandler(this.btnDeleteUser_Click);
            // 
            // btnAddUser
            // 
            this.btnAddUser.Location = new System.Drawing.Point(6, 167);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(176, 33);
            this.btnAddUser.TabIndex = 4;
            this.btnAddUser.Text = "Добавить";
            this.btnAddUser.UseVisualStyleBackColor = true;
            this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // cmbUserRole
            // 
            this.cmbUserRole.FormattingEnabled = true;
            this.cmbUserRole.Items.AddRange(new object[] {
            "Admin",
            "Manager",
            "Master"});
            this.cmbUserRole.Location = new System.Drawing.Point(9, 126);
            this.cmbUserRole.Name = "cmbUserRole";
            this.cmbUserRole.Size = new System.Drawing.Size(283, 24);
            this.cmbUserRole.TabIndex = 8;
            // 
            // txtUserFio
            // 
            this.txtUserFio.Location = new System.Drawing.Point(70, 83);
            this.txtUserFio.Name = "txtUserFio";
            this.txtUserFio.Size = new System.Drawing.Size(222, 22);
            this.txtUserFio.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "ФИО";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Пароль";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Логин";
            // 
            // txtUserPass
            // 
            this.txtUserPass.Location = new System.Drawing.Point(70, 49);
            this.txtUserPass.Name = "txtUserPass";
            this.txtUserPass.Size = new System.Drawing.Size(222, 22);
            this.txtUserPass.TabIndex = 1;
            // 
            // txtUserLogin
            // 
            this.txtUserLogin.Location = new System.Drawing.Point(70, 21);
            this.txtUserLogin.Name = "txtUserLogin";
            this.txtUserLogin.Size = new System.Drawing.Size(222, 22);
            this.txtUserLogin.TabIndex = 0;
            // 
            // dgvEmployees
            // 
            this.dgvEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmployees.Location = new System.Drawing.Point(11, 22);
            this.dgvEmployees.Name = "dgvEmployees";
            this.dgvEmployees.RowHeadersWidth = 51;
            this.dgvEmployees.RowTemplate.Height = 24;
            this.dgvEmployees.Size = new System.Drawing.Size(326, 310);
            this.dgvEmployees.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl2);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(792, 340);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Справочники";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Location = new System.Drawing.Point(11, 16);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(773, 318);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btnDeleteCategory);
            this.tabPage5.Controls.Add(this.lstCategories);
            this.tabPage5.Controls.Add(this.btnAddCategory);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Controls.Add(this.txtNewCategoryName);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(765, 289);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Категории";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // btnDeleteCategory
            // 
            this.btnDeleteCategory.BackColor = System.Drawing.Color.Red;
            this.btnDeleteCategory.Location = new System.Drawing.Point(9, 128);
            this.btnDeleteCategory.Name = "btnDeleteCategory";
            this.btnDeleteCategory.Size = new System.Drawing.Size(248, 33);
            this.btnDeleteCategory.TabIndex = 6;
            this.btnDeleteCategory.Text = "Удалить категорию ";
            this.btnDeleteCategory.UseVisualStyleBackColor = false;
            this.btnDeleteCategory.Click += new System.EventHandler(this.btnDeleteCategory_Click);
            // 
            // lstCategories
            // 
            this.lstCategories.FormattingEnabled = true;
            this.lstCategories.ItemHeight = 16;
            this.lstCategories.Location = new System.Drawing.Point(286, 13);
            this.lstCategories.Name = "lstCategories";
            this.lstCategories.Size = new System.Drawing.Size(473, 260);
            this.lstCategories.TabIndex = 5;
            // 
            // btnAddCategory
            // 
            this.btnAddCategory.BackColor = System.Drawing.Color.Lime;
            this.btnAddCategory.Location = new System.Drawing.Point(6, 79);
            this.btnAddCategory.Name = "btnAddCategory";
            this.btnAddCategory.Size = new System.Drawing.Size(248, 33);
            this.btnAddCategory.TabIndex = 4;
            this.btnAddCategory.Text = "Добавить новую категорию";
            this.btnAddCategory.UseVisualStyleBackColor = false;
            this.btnAddCategory.Click += new System.EventHandler(this.btnAddCategory_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Новая категория";
            // 
            // txtNewCategoryName
            // 
            this.txtNewCategoryName.Location = new System.Drawing.Point(9, 42);
            this.txtNewCategoryName.Name = "txtNewCategoryName";
            this.txtNewCategoryName.Size = new System.Drawing.Size(259, 22);
            this.txtNewCategoryName.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dgvSuppliers);
            this.tabPage6.Controls.Add(this.pnlSuppliersBottom);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(765, 289);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Поставщики";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dgvSuppliers
            // 
            this.dgvSuppliers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSuppliers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSuppliers.Location = new System.Drawing.Point(3, 3);
            this.dgvSuppliers.Name = "dgvSuppliers";
            this.dgvSuppliers.RowHeadersWidth = 51;
            this.dgvSuppliers.RowTemplate.Height = 24;
            this.dgvSuppliers.Size = new System.Drawing.Size(759, 233);
            this.dgvSuppliers.TabIndex = 1;
            // 
            // pnlSuppliersBottom
            // 
            this.pnlSuppliersBottom.Controls.Add(this.btnDeleteSupplier);
            this.pnlSuppliersBottom.Controls.Add(this.btnOpenAddSupplier);
            this.pnlSuppliersBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlSuppliersBottom.Location = new System.Drawing.Point(3, 236);
            this.pnlSuppliersBottom.Name = "pnlSuppliersBottom";
            this.pnlSuppliersBottom.Size = new System.Drawing.Size(759, 50);
            this.pnlSuppliersBottom.TabIndex = 0;
            // 
            // btnDeleteSupplier
            // 
            this.btnDeleteSupplier.Location = new System.Drawing.Point(580, 14);
            this.btnDeleteSupplier.Name = "btnDeleteSupplier";
            this.btnDeleteSupplier.Size = new System.Drawing.Size(176, 26);
            this.btnDeleteSupplier.TabIndex = 5;
            this.btnDeleteSupplier.Text = "Удалить";
            this.btnDeleteSupplier.UseVisualStyleBackColor = true;
            this.btnDeleteSupplier.Click += new System.EventHandler(this.btnDeleteSupplier_Click);
            // 
            // btnOpenAddSupplier
            // 
            this.btnOpenAddSupplier.Location = new System.Drawing.Point(3, 14);
            this.btnOpenAddSupplier.Name = "btnOpenAddSupplier";
            this.btnOpenAddSupplier.Size = new System.Drawing.Size(176, 26);
            this.btnOpenAddSupplier.TabIndex = 4;
            this.btnOpenAddSupplier.Text = "Добавить";
            this.btnOpenAddSupplier.UseVisualStyleBackColor = true;
            this.btnOpenAddSupplier.Click += new System.EventHandler(this.btnOpenAddSupplier_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.lblSupplyTotal);
            this.tabPage7.Controls.Add(this.lstSupplyDraft);
            this.tabPage7.Controls.Add(this.button2);
            this.tabPage7.Controls.Add(this.btnAddSupplyItem);
            this.tabPage7.Controls.Add(this.numSupplyPrice);
            this.tabPage7.Controls.Add(this.label11);
            this.tabPage7.Controls.Add(this.numSupplyQty);
            this.tabPage7.Controls.Add(this.label10);
            this.tabPage7.Controls.Add(this.cmbSupplyProduct);
            this.tabPage7.Controls.Add(this.label9);
            this.tabPage7.Controls.Add(this.rbPart);
            this.tabPage7.Controls.Add(this.rbAccessory);
            this.tabPage7.Controls.Add(this.cmbSupplySupplier);
            this.tabPage7.Controls.Add(this.label8);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(765, 289);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "Поставка";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // lblSupplyTotal
            // 
            this.lblSupplyTotal.AutoSize = true;
            this.lblSupplyTotal.Location = new System.Drawing.Point(439, 77);
            this.lblSupplyTotal.Name = "lblSupplyTotal";
            this.lblSupplyTotal.Size = new System.Drawing.Size(187, 16);
            this.lblSupplyTotal.TabIndex = 13;
            this.lblSupplyTotal.Text = "Итоговая сумма накладной";
            // 
            // lstSupplyDraft
            // 
            this.lstSupplyDraft.FormattingEnabled = true;
            this.lstSupplyDraft.ItemHeight = 16;
            this.lstSupplyDraft.Location = new System.Drawing.Point(442, 100);
            this.lstSupplyDraft.Name = "lstSupplyDraft";
            this.lstSupplyDraft.Size = new System.Drawing.Size(307, 180);
            this.lstSupplyDraft.TabIndex = 12;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(233, 252);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(203, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "Оформить поставку";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnAddSupplyItem
            // 
            this.btnAddSupplyItem.Location = new System.Drawing.Point(3, 252);
            this.btnAddSupplyItem.Name = "btnAddSupplyItem";
            this.btnAddSupplyItem.Size = new System.Drawing.Size(212, 23);
            this.btnAddSupplyItem.TabIndex = 10;
            this.btnAddSupplyItem.Text = "Добавить в накладную";
            this.btnAddSupplyItem.UseVisualStyleBackColor = true;
            this.btnAddSupplyItem.Click += new System.EventHandler(this.btnAddSupplyItem_Click);
            // 
            // numSupplyPrice
            // 
            this.numSupplyPrice.Location = new System.Drawing.Point(547, 34);
            this.numSupplyPrice.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.numSupplyPrice.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numSupplyPrice.Name = "numSupplyPrice";
            this.numSupplyPrice.Size = new System.Drawing.Size(120, 22);
            this.numSupplyPrice.TabIndex = 9;
            this.numSupplyPrice.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(544, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "Цена закупки";
            // 
            // numSupplyQty
            // 
            this.numSupplyQty.Location = new System.Drawing.Point(409, 34);
            this.numSupplyQty.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.numSupplyQty.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numSupplyQty.Name = "numSupplyQty";
            this.numSupplyQty.Size = new System.Drawing.Size(120, 22);
            this.numSupplyQty.TabIndex = 7;
            this.numSupplyQty.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(406, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 16);
            this.label10.TabIndex = 6;
            this.label10.Text = "Количество";
            // 
            // cmbSupplyProduct
            // 
            this.cmbSupplyProduct.FormattingEnabled = true;
            this.cmbSupplyProduct.Location = new System.Drawing.Point(233, 33);
            this.cmbSupplyProduct.Name = "cmbSupplyProduct";
            this.cmbSupplyProduct.Size = new System.Drawing.Size(121, 24);
            this.cmbSupplyProduct.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(230, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 16);
            this.label9.TabIndex = 4;
            this.label9.Text = "Выбор товара";
            // 
            // rbPart
            // 
            this.rbPart.AutoSize = true;
            this.rbPart.Location = new System.Drawing.Point(28, 112);
            this.rbPart.Name = "rbPart";
            this.rbPart.Size = new System.Drawing.Size(175, 20);
            this.rbPart.TabIndex = 3;
            this.rbPart.Text = "Запчасть для ремонта";
            this.rbPart.UseVisualStyleBackColor = true;
            this.rbPart.CheckedChanged += new System.EventHandler(this.rbPart_CheckedChanged);
            // 
            // rbAccessory
            // 
            this.rbAccessory.AutoSize = true;
            this.rbAccessory.Checked = true;
            this.rbAccessory.Location = new System.Drawing.Point(28, 77);
            this.rbAccessory.Name = "rbAccessory";
            this.rbAccessory.Size = new System.Drawing.Size(142, 20);
            this.rbAccessory.TabIndex = 2;
            this.rbAccessory.TabStop = true;
            this.rbAccessory.Text = "Аксессуар/Товар";
            this.rbAccessory.UseVisualStyleBackColor = true;
            this.rbAccessory.CheckedChanged += new System.EventHandler(this.rbAccessory_CheckedChanged);
            // 
            // cmbSupplySupplier
            // 
            this.cmbSupplySupplier.FormattingEnabled = true;
            this.cmbSupplySupplier.Location = new System.Drawing.Point(28, 33);
            this.cmbSupplySupplier.Name = "cmbSupplySupplier";
            this.cmbSupplySupplier.Size = new System.Drawing.Size(121, 24);
            this.cmbSupplySupplier.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "Поставщик";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(792, 340);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Система и Безопасность";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnRestore);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Location = new System.Drawing.Point(11, 125);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(387, 104);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Востановление";
            // 
            // btnRestore
            // 
            this.btnRestore.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRestore.Location = new System.Drawing.Point(7, 42);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(374, 41);
            this.btnRestore.TabIndex = 1;
            this.btnRestore.Text = "ВОСCТАНОВИТЬ ИЗ ФАЙЛА";
            this.btnRestore.UseVisualStyleBackColor = true;
            this.btnRestore.Click += new System.EventHandler(this.btnRestore_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(299, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Внимание! Текущие данные будут заменены";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnBackup);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(11, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(358, 104);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Резервное копирование";
            // 
            // btnBackup
            // 
            this.btnBackup.Location = new System.Drawing.Point(7, 42);
            this.btnBackup.Name = "btnBackup";
            this.btnBackup.Size = new System.Drawing.Size(336, 41);
            this.btnBackup.TabIndex = 1;
            this.btnBackup.Text = "Создать резервную копию";
            this.btnBackup.UseVisualStyleBackColor = true;
            this.btnBackup.Click += new System.EventHandler(this.btnBackup_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(251, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "Создание полной копии базы данных";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.btnSetPhoto);
            this.tabPage8.Controls.Add(this.btnRefreshStock);
            this.tabPage8.Controls.Add(this.dgvStock);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(765, 289);
            this.tabPage8.TabIndex = 3;
            this.tabPage8.Text = "Склад";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // dgvStock
            // 
            this.dgvStock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStock.Location = new System.Drawing.Point(4, 4);
            this.dgvStock.Name = "dgvStock";
            this.dgvStock.RowHeadersWidth = 51;
            this.dgvStock.RowTemplate.Height = 24;
            this.dgvStock.Size = new System.Drawing.Size(758, 228);
            this.dgvStock.TabIndex = 0;
            // 
            // btnRefreshStock
            // 
            this.btnRefreshStock.Location = new System.Drawing.Point(4, 238);
            this.btnRefreshStock.Name = "btnRefreshStock";
            this.btnRefreshStock.Size = new System.Drawing.Size(176, 33);
            this.btnRefreshStock.TabIndex = 4;
            this.btnRefreshStock.Text = "Обновить склад";
            this.btnRefreshStock.UseVisualStyleBackColor = true;
            this.btnRefreshStock.Click += new System.EventHandler(this.btnRefreshStock_Click);
            // 
            // btnSetPhoto
            // 
            this.btnSetPhoto.Location = new System.Drawing.Point(575, 238);
            this.btnSetPhoto.Name = "btnSetPhoto";
            this.btnSetPhoto.Size = new System.Drawing.Size(176, 33);
            this.btnSetPhoto.TabIndex = 5;
            this.btnSetPhoto.Text = "Добавить фото";
            this.btnSetPhoto.UseVisualStyleBackColor = true;
            this.btnSetPhoto.Click += new System.EventHandler(this.btnSetPhoto_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.pnlAdminHeader);
            this.Name = "AdminForm";
            this.Text = "Администратор";
            this.Load += new System.EventHandler(this.AdminForm_Load);
            this.pnlAdminHeader.ResumeLayout(false);
            this.pnlAdminHeader.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartRevenue)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).EndInit();
            this.pnlSuppliersBottom.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSupplyPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSupplyQty)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStock)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAdminHeader;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnOpenManager;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnOpenMaster;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label lblTotalProfit;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartRevenue;
        private System.Windows.Forms.Button btnShowReport;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtUserPass;
        private System.Windows.Forms.TextBox txtUserLogin;
        private System.Windows.Forms.DataGridView dgvEmployees;
        private System.Windows.Forms.TextBox txtUserFio;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnDeleteUser;
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.ComboBox cmbUserRole;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ListBox lstCategories;
        private System.Windows.Forms.Button btnAddCategory;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNewCategoryName;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnBackup;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnDeleteCategory;
        private System.Windows.Forms.DataGridView dgvSuppliers;
        private System.Windows.Forms.Panel pnlSuppliersBottom;
        private System.Windows.Forms.Button btnDeleteSupplier;
        private System.Windows.Forms.Button btnOpenAddSupplier;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.NumericUpDown numSupplyQty;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbSupplyProduct;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rbPart;
        private System.Windows.Forms.RadioButton rbAccessory;
        private System.Windows.Forms.ComboBox cmbSupplySupplier;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblSupplyTotal;
        private System.Windows.Forms.ListBox lstSupplyDraft;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnAddSupplyItem;
        private System.Windows.Forms.NumericUpDown numSupplyPrice;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button btnRefreshStock;
        private System.Windows.Forms.DataGridView dgvStock;
        private System.Windows.Forms.Button btnSetPhoto;
    }
}