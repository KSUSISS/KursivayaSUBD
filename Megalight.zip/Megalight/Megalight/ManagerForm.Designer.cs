﻿namespace Megalight
{
    partial class ManagerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlSidebar = new System.Windows.Forms.Panel();
            this.btnOpenBuyback = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnCatServices = new System.Windows.Forms.Button();
            this.btnCatAccessories = new System.Windows.Forms.Button();
            this.btnCatDevices = new System.Windows.Forms.Button();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblHeaderTitle = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.pnlCart = new System.Windows.Forms.Panel();
            this.lstCart = new System.Windows.Forms.ListBox();
            this.btnPay = new System.Windows.Forms.Button();
            this.btnClearCart = new System.Windows.Forms.Button();
            this.lblTotalSum = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.flowPanelCatalog = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlSidebar.SuspendLayout();
            this.pnlHeader.SuspendLayout();
            this.pnlCart.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSidebar
            // 
            this.pnlSidebar.AutoScroll = true;
            this.pnlSidebar.AutoScrollMinSize = new System.Drawing.Size(200, 0);
            this.pnlSidebar.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pnlSidebar.Controls.Add(this.btnOpenBuyback);
            this.pnlSidebar.Controls.Add(this.button1);
            this.pnlSidebar.Controls.Add(this.btnCatServices);
            this.pnlSidebar.Controls.Add(this.btnCatAccessories);
            this.pnlSidebar.Controls.Add(this.btnCatDevices);
            this.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSidebar.Location = new System.Drawing.Point(0, 0);
            this.pnlSidebar.Name = "pnlSidebar";
            this.pnlSidebar.Size = new System.Drawing.Size(188, 585);
            this.pnlSidebar.TabIndex = 0;
            // 
            // btnOpenBuyback
            // 
            this.btnOpenBuyback.FlatAppearance.BorderSize = 0;
            this.btnOpenBuyback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpenBuyback.Location = new System.Drawing.Point(0, 198);
            this.btnOpenBuyback.Name = "btnOpenBuyback";
            this.btnOpenBuyback.Size = new System.Drawing.Size(190, 60);
            this.btnOpenBuyback.TabIndex = 5;
            this.btnOpenBuyback.Text = "Скупка";
            this.btnOpenBuyback.UseVisualStyleBackColor = true;
            this.btnOpenBuyback.Click += new System.EventHandler(this.btnOpenBuyback_Click);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(0, 339);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(193, 60);
            this.button1.TabIndex = 4;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCatServices
            // 
            this.btnCatServices.FlatAppearance.BorderSize = 0;
            this.btnCatServices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCatServices.Location = new System.Drawing.Point(3, 132);
            this.btnCatServices.Name = "btnCatServices";
            this.btnCatServices.Size = new System.Drawing.Size(190, 60);
            this.btnCatServices.TabIndex = 2;
            this.btnCatServices.Text = "Услуги";
            this.btnCatServices.UseVisualStyleBackColor = true;
            this.btnCatServices.Click += new System.EventHandler(this.btnCatServices_Click);
            // 
            // btnCatAccessories
            // 
            this.btnCatAccessories.FlatAppearance.BorderSize = 0;
            this.btnCatAccessories.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCatAccessories.Location = new System.Drawing.Point(3, 66);
            this.btnCatAccessories.Name = "btnCatAccessories";
            this.btnCatAccessories.Size = new System.Drawing.Size(190, 60);
            this.btnCatAccessories.TabIndex = 1;
            this.btnCatAccessories.Text = "Аксессуары";
            this.btnCatAccessories.UseVisualStyleBackColor = true;
            this.btnCatAccessories.Click += new System.EventHandler(this.btnCatAccessories_Click);
            // 
            // btnCatDevices
            // 
            this.btnCatDevices.FlatAppearance.BorderSize = 0;
            this.btnCatDevices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCatDevices.Location = new System.Drawing.Point(3, 3);
            this.btnCatDevices.Name = "btnCatDevices";
            this.btnCatDevices.Size = new System.Drawing.Size(187, 57);
            this.btnCatDevices.TabIndex = 0;
            this.btnCatDevices.Text = "Телефоны";
            this.btnCatDevices.UseVisualStyleBackColor = true;
            this.btnCatDevices.Click += new System.EventHandler(this.btnCatDevices_Click);
            // 
            // pnlHeader
            // 
            this.pnlHeader.AutoScroll = true;
            this.pnlHeader.AutoScrollMinSize = new System.Drawing.Size(0, 60);
            this.pnlHeader.Controls.Add(this.lblHeaderTitle);
            this.pnlHeader.Controls.Add(this.txtSearch);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(188, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(755, 60);
            this.pnlHeader.TabIndex = 1;
            // 
            // lblHeaderTitle
            // 
            this.lblHeaderTitle.AutoSize = true;
            this.lblHeaderTitle.Font = new System.Drawing.Font("DOCKER THREE", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeaderTitle.Location = new System.Drawing.Point(6, 9);
            this.lblHeaderTitle.Name = "lblHeaderTitle";
            this.lblHeaderTitle.Size = new System.Drawing.Size(205, 20);
            this.lblHeaderTitle.TabIndex = 1;
            this.lblHeaderTitle.Text = "ПОИСК ТОВАРА";
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("DOCKER THREE", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(463, 4);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(289, 22);
            this.txtSearch.TabIndex = 0;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // pnlCart
            // 
            this.pnlCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pnlCart.Controls.Add(this.lstCart);
            this.pnlCart.Controls.Add(this.btnPay);
            this.pnlCart.Controls.Add(this.btnClearCart);
            this.pnlCart.Controls.Add(this.lblTotalSum);
            this.pnlCart.Controls.Add(this.label2);
            this.pnlCart.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlCart.Location = new System.Drawing.Point(643, 60);
            this.pnlCart.Name = "pnlCart";
            this.pnlCart.Size = new System.Drawing.Size(300, 525);
            this.pnlCart.TabIndex = 2;
            // 
            // lstCart
            // 
            this.lstCart.FormattingEnabled = true;
            this.lstCart.ItemHeight = 16;
            this.lstCart.Location = new System.Drawing.Point(25, 35);
            this.lstCart.Name = "lstCart";
            this.lstCart.Size = new System.Drawing.Size(250, 292);
            this.lstCart.TabIndex = 5;
            // 
            // btnPay
            // 
            this.btnPay.BackColor = System.Drawing.Color.ForestGreen;
            this.btnPay.Location = new System.Drawing.Point(145, 339);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(130, 36);
            this.btnPay.TabIndex = 4;
            this.btnPay.Text = "ОПЛАТИТЬ";
            this.btnPay.UseVisualStyleBackColor = false;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // btnClearCart
            // 
            this.btnClearCart.Location = new System.Drawing.Point(10, 339);
            this.btnClearCart.Name = "btnClearCart";
            this.btnClearCart.Size = new System.Drawing.Size(98, 23);
            this.btnClearCart.TabIndex = 3;
            this.btnClearCart.Text = "Очистить";
            this.btnClearCart.UseVisualStyleBackColor = true;
            this.btnClearCart.Click += new System.EventHandler(this.btnClearCart_Click);
            // 
            // lblTotalSum
            // 
            this.lblTotalSum.AutoSize = true;
            this.lblTotalSum.Font = new System.Drawing.Font("DOCKER THREE", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalSum.Location = new System.Drawing.Point(6, 384);
            this.lblTotalSum.Name = "lblTotalSum";
            this.lblTotalSum.Size = new System.Drawing.Size(208, 20);
            this.lblTotalSum.TabIndex = 1;
            this.lblTotalSum.Text = "Итого : 0 руб";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ваш заказ";
            // 
            // flowPanelCatalog
            // 
            this.flowPanelCatalog.AutoScroll = true;
            this.flowPanelCatalog.AutoSize = true;
            this.flowPanelCatalog.BackColor = System.Drawing.Color.White;
            this.flowPanelCatalog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowPanelCatalog.Location = new System.Drawing.Point(188, 60);
            this.flowPanelCatalog.Name = "flowPanelCatalog";
            this.flowPanelCatalog.Size = new System.Drawing.Size(455, 525);
            this.flowPanelCatalog.TabIndex = 3;
            // 
            // ManagerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 585);
            this.Controls.Add(this.flowPanelCatalog);
            this.Controls.Add(this.pnlCart);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.pnlSidebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "ManagerForm";
            this.Text = "Продавец";
            this.Load += new System.EventHandler(this.ManagerForm_Load);
            this.pnlSidebar.ResumeLayout(false);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.pnlCart.ResumeLayout(false);
            this.pnlCart.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Button btnCatAccessories;
        private System.Windows.Forms.Button btnCatDevices;
        private System.Windows.Forms.Button btnCatServices;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblHeaderTitle;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Panel pnlCart;
        private System.Windows.Forms.Label lblTotalSum;
        private System.Windows.Forms.Label label2;
    
        private System.Windows.Forms.ListBox lstCart;
        private System.Windows.Forms.Button btnPay;
        private System.Windows.Forms.Button btnClearCart;
        private System.Windows.Forms.FlowLayoutPanel flowPanelCatalog;
        private System.Windows.Forms.Button btnOpenBuyback;
    }
}